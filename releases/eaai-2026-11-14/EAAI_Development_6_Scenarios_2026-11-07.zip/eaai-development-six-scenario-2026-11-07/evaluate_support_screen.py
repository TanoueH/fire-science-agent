"""Evaluate an uncalibrated train-range abstention screen on development folds."""
from pathlib import Path
import json
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
DATA = pd.read_csv(ROOT / 'data/development-device-data-long.csv')
PRED = pd.read_csv(ROOT / 'results/development-predictions.csv')
OBSERVED = ['S01', 'S02', 'S09', 'S10']
TARGETS = ['S03', 'S04', 'S05', 'S06', 'S07', 'S08']
FIELDS = ['temperature_C', 'visibility_m', 'CO_ppm']
INPUT_FIELDS = FIELDS + ['U_m_s']
SCENARIOS = ['S1', 'S2', 'S3', 'P05V02', 'P10V03', 'P20V01']
OUT = ROOT / 'results'


def make_X(frame):
    times = np.sort(frame.time_s.unique())
    coords = frame.groupby('sensor_id')[['x_m', 'z_m']].first().loc[TARGETS]
    wide = {field: frame.pivot(index='time_s', columns='sensor_id', values=field).reindex(times)
            for field in INPUT_FIELDS}
    observed = np.column_stack([wide[field][site].to_numpy()
                                for field in INPUT_FIELDS for site in OBSERVED])
    locs = coords.to_numpy()
    X = np.column_stack([np.repeat(observed, len(TARGETS), axis=0),
                         np.tile(locs, (len(times), 1))])
    meta = pd.DataFrame({'scenario': frame.scenario.iloc[0],
                         'time_s': np.repeat(times, len(TARGETS)),
                         'target_site': np.tile(TARGETS, len(times))})
    return X, meta


def get_metrics(frame, mask):
    output = {}
    for field in FIELDS:
        error = frame.loc[mask, 'estimate_' + field].to_numpy() - frame.loc[mask, 'reference_' + field].to_numpy()
        if len(error):
            output[field + '_MAE'] = float(np.abs(error).mean())
            output[field + '_RMSE'] = float(np.sqrt(np.mean(error ** 2)))
        else:
            output[field + '_MAE'] = None
            output[field + '_RMSE'] = None
    actual = frame.loc[mask, 'reference_local_band'].to_numpy(dtype=int)
    estimate = frame.loc[mask, 'estimated_local_band'].to_numpy(dtype=int)
    output['severity_band_agreement'] = float(np.mean(actual == estimate)) if len(actual) else None
    output['severity_underestimate_fraction'] = float(np.mean(estimate < actual)) if len(actual) else None
    output['rows'] = int(mask.sum())
    return output


rows = []
coverage_rows = []
for heldout in SCENARIOS:
    train_frames = [DATA[DATA.scenario == name] for name in SCENARIOS if name != heldout]
    train_X = np.concatenate([make_X(frame)[0] for frame in train_frames])
    test_frame = DATA[DATA.scenario == heldout]
    test_X, meta = make_X(test_frame)
    supported = np.all((test_X >= train_X.min(axis=0)) & (test_X <= train_X.max(axis=0)), axis=1)
    meta['inside_training_feature_minmax'] = supported
    coverage = float(supported.mean())
    coverage_rows.append({'test_scenario': heldout, 'rows': len(meta),
                          'supported_rows': int(supported.sum()), 'coverage': coverage})

    for method in sorted(PRED[PRED.scenario == heldout].method.unique()):
        frame = PRED[(PRED.scenario == heldout) & (PRED.method == method)].merge(
            meta, on=['scenario', 'time_s', 'target_site'], validate='one_to_one')
        if len(frame) != 3606:
            raise ValueError(f'Prediction/support rows do not align for {heldout}/{method}')
        for label, mask in [('all_rows', np.ones(len(frame), dtype=bool)),
                            ('inside_training_feature_minmax', frame.inside_training_feature_minmax.to_numpy()),
                            ('outside_training_feature_minmax', ~frame.inside_training_feature_minmax.to_numpy())]:
            record = {'test_scenario': heldout, 'method': method, 'subset': label,
                      'support_coverage': coverage}
            record.update(get_metrics(frame, mask))
            rows.append(record)

coverage_df = pd.DataFrame(coverage_rows)
metrics_df = pd.DataFrame(rows)
coverage_df.to_csv(OUT / 'candidate-support-screen-coverage.csv', index=False)
metrics_df.to_csv(OUT / 'candidate-support-screen-metrics.csv', index=False)

summary = {
    'rule': 'return estimate unavailable for a time point if any of 18 predictors falls outside the min-max range in the five training scenarios',
    'status': 'candidate diagnostic only; no sensor-resolution threshold, joint-density calibration, or operational validation',
    'rule_applied_equally_to_all_methods': True,
    'reserved_holdout_histories_accessed': False,
    'coverage': coverage_rows,
    'support_subset_metrics': metrics_df[metrics_df.subset == 'inside_training_feature_minmax'].to_dict(orient='records'),
}
(ROOT / 'audit/candidate-support-screen.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')

lines = [
    '# Candidato a regra de abstinência: faixa min–max', '',
    'Regra exploratória aplicada a todos os métodos por igual: para um instante, emitir estimativa somente se as 18 entradas '
    '(16 leituras observadas + x,z do alvo) estiverem dentro dos mínimos e máximos do treino. Caso contrário, marcar '
    '`estimativa indisponível`. Esta regra não foi calibrada para resolução de sensores, não verifica combinações conjuntas '
    'de entradas e ainda não é uma regra operacional validada.', '',
    '| Cenário avaliado | Linhas aplicáveis / 3606 | Cobertura |', '|---|---:|---:|',
]
for row in coverage_rows:
    lines.append(f"| {row['test_scenario']} | {row['supported_rows']} / {row['rows']} | {row['coverage']:.2%} |")
lines += ['', '## Erros dentro da faixa do treino', '',
          'Cada métrica abaixo usa apenas os instantes onde a regra emitiria estimativa. Unidades continuam separadas.', '',
          '| Cenário | Método | MAE T (°C) | MAE vis. (m) | MAE CO (ppm) | Concordância de faixa | Subestimação |',
          '|---|---|---:|---:|---:|---:|---:|']
eligible = metrics_df[metrics_df.subset == 'inside_training_feature_minmax']
for row in eligible.to_dict(orient='records'):
    def fmt(x): return '—' if x is None or pd.isna(x) else f'{x:.5g}'
    lines.append(f"| {row['test_scenario']} | {row['method']} | {fmt(row['temperature_C_MAE'])} | "
                 f"{fmt(row['visibility_m_MAE'])} | {fmt(row['CO_ppm_MAE'])} | "
                 f"{fmt(row['severity_band_agreement'])} | {fmt(row['severity_underestimate_fraction'])} |")
lines += ['', 'Este resultado demonstra apenas a relação entre faixa de entradas e cobertura/erro nestes seis cenários CFD. '
          'O critério não pode ser chamado de sensor digital validado, classificação de risco confiável ou garantia de segurança. '
          'A regra deve permanecer em desenvolvimento até ser congelada antes de qualquer abertura do conjunto reservado.', '']
(OUT / 'candidate-support-screen.md').write_text('\n'.join(lines), encoding='utf-8')
print(json.dumps({'coverage': coverage_rows, 'support_metrics_rows': int(len(eligible)),
                  'all_methods_screened_equally': True,
                  'holdout_histories_accessed': False}, indent=2))
