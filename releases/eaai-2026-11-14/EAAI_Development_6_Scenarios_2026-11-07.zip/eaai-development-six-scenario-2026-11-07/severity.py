"""Versioned research-only interpretation of local simulated conditions.

New specification from the 2026-11-05 methodological review; not a recovered
three-class algorithm, a validated human-tenability model or Mamdani inference.
"""
import numpy as np

VERSION='local-severity-research-2.0'
LABELS=('Low','Medium','High','Critical')
ANCHORS={
    'temperature_C':([20.,40.,80.,150.],[0.,1/3,2/3,1.]),
    'visibility_m':([5.,10.,20.,30.],[1.,2/3,1/3,0.]),
    'CO_ppm':([0.,50.,200.,800.],[0.,1/3,2/3,1.]),
}


def evaluate(values):
    """values[:,0:3] = Celsius, visibility metres, CO ppm.

    Reject missing/nonfinite/invalid data instead of inferring normality.
    Return per-component bands/gradual indicators and their maxima.
    """
    data=np.asarray(values,dtype=float)
    if data.ndim!=2 or data.shape[1]!=3 or data.shape[0]==0:
        raise ValueError('Expected nonempty n x 3 local measurements.')
    if not np.isfinite(data).all():
        raise ValueError('Nonfinite or missing measurement; severity unavailable.')
    if (data[:,0]<-273.15).any() or (data[:,1:]<0).any() or (data[:,2]>1e6).any():
        raise ValueError('Measurement outside the supported physical representation.')
    bands=np.column_stack([
        np.searchsorted([40.,80.,150.],data[:,0],side='right'),
        np.searchsorted([-20.,-10.,-5.],-data[:,1],side='right'),
        np.searchsorted([50.,200.,800.],data[:,2],side='right'),
    ])
    indicators=np.column_stack([
        np.interp(data[:,i],*ANCHORS[key])
        for i,key in enumerate(('temperature_C','visibility_m','CO_ppm'))
    ])
    return {'component_bands':bands,'band':bands.max(axis=1),
            'component_indicators':indicators,'indicator':indicators.max(axis=1)}


def project_predictions(values):
    data=np.asarray(values,dtype=float)
    if data.ndim!=2 or data.shape[1]!=3 or not np.isfinite(data).all():
        raise ValueError('Invalid reconstructed values.')
    projected=data.copy()
    projected[:,0]=np.maximum(projected[:,0],-273.15)
    projected[:,1]=np.clip(projected[:,1],0,30)
    projected[:,2]=np.clip(projected[:,2],0,1e6)
    return projected,projected!=data
