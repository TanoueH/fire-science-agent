# Desenvolvimento da reconstrução em seis cenários

Data do protocolo: 7 de novembro de 2026. Esta é uma etapa de desenvolvimento, não a avaliação final reservada.

## Casos

Usar os três casos corrigidos já analisados (S1, S2 e S3) mais os resultados novos P05V02, P10V03 e P20V01. Não incluir P05V03, P10V01 nem P20V02 nesta etapa. Esses três continuam reservados para a futura avaliação após o congelamento do método.

Os seis cenários de desenvolvimento cobrem nominalmente 5, 10 e 20 MW e diferentes velocidades de entrada. Os novos casos são combinações cruzadas da campanha FDS; não introduzem nova geometria ou validação experimental.

## Pergunta e protocolo

Avaliar, em caráter de desenvolvimento, a reconstrução contemporânea de temperatura, visibilidade e CO em seis posições internas omitidas, usando valores simultâneos de T, visibilidade, CO e velocidade em S01, S02, S09 e S10, além das coordenadas x e z do alvo. S03–S08 são alvos. Tempo, cenário, potência, ventilação e grandezas do local-alvo não são preditores.

Usar validação cruzada por cenário completo: seis rodadas; em cada rodada, cinco cenários treinam e o sexto é avaliado. Nenhuma linha temporal de um cenário avaliado pode entrar no treino daquela rodada. Os 601 instantes e seis alvos de cada simulação são amostras correlacionadas e não representam 3606 incêndios independentes.

Comparadores e parâmetros permanecem os da análise anterior: vizinho longitudinal mais próximo do mesmo lado (empate resolvido pelo ponto a montante); interpolação linear entre os dois sensores observados do mesmo lado; Ridge com `StandardScaler` ajustado apenas no treino e `alpha=1`; Random Forest com 100 árvores, profundidade máxima 10, mínimo de cinco observações por folha, semente 42 e um processo. Não realizar busca de hiperparâmetros nesta rodada.

Após a previsão, usar somente os limites de representação já definidos: temperatura >= -273,15 °C, visibilidade entre 0 e 30 m e CO entre 0 e 10^6 ppm. Registrar a fração de previsões projetadas. Apresentar MAE, RMSE, erro absoluto máximo, viés e R² quando definido, separadamente por cenário, grandeza e método; não combinar unidades distintas.

Para a leitura de severidade metodológica, manter a versão de pesquisa documentada na análise anterior (T 40/80/150 °C; visibilidade 20/10/5 m; CO 50/200/800 ppm; faixa máxima entre componentes, sem compensação). Concordância e subestimação avaliam apenas o efeito da reconstrução nessa regra local; não validam segurança humana, alarmes, risco probabilístico ou limites normativos.

## Interpretação e reserva

Os resultados destas seis rodadas podem orientar decisões de método. Se ocorrer qualquer alteração de pré-processamento, preditores, modelo, regra de aplicabilidade ou hiperparâmetros após inspecionar esses resultados, registrá-la como desenvolvimento. Antes de abrir as histórias dos alvos de P05V03, P10V01 e P20V02, fixar por escrito a versão final do método, transformações ajustadas somente no treino, regras de disponibilidade e métricas.

Mesmo uma avaliação reservada favorável sustentará somente generalização entre cenários CFD desta mesma geometria e configuração. Não demonstrará validade em túnel real, malha independente, outras geometrias ou benefício operacional de IA.
