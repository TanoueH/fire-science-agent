# Revisão da etapa de desenvolvimento com seis cenários

**Estado: desenvolvimento exploratório.** A etapa foi concluída sem abrir as séries dos casos reservados P05V03, P10V01 e P20V02. Os resultados não são validação física nem resultado final de submissão.

## 1. Conferência dos novos casos

| Caso | Entrada confere com SHA-256 preparado | FDS | Entrada (m/s, normal) | HRR médio em 300–600 s | Série DEVC |
|---|---:|---|---:|---:|---|
| P05V02 | Sim | 6.8.0 | −2 | 5,00017 MW | 601 pontos, 0–600 s |
| P10V03 | Sim | 6.8.0 | −3 | 10,00082 MW | 601 pontos, 0–600 s |
| P20V01 | Sim | 6.8.0 | −1 | 20,00131 MW | 601 pontos, 0–600 s |

Nos três arquivos, o ambiente é 20 °C e `GVEC=(0,−9.81,0)`. Os 40 canais dos dez locais e seis canais QA estão presentes; a coluna de tempo completa as 47 colunas do DEVC. Séries DEVC e HRR terminam em 600 s, e não há valores não finitos nos dados analisados. Os 36.060 registros consolidados são seis cenários × dez posições × 601 instantes. A fração de CO foi convertida de mol/mol para ppm multiplicando por 10⁶. As coordenadas dos dez locais coincidem com a configuração já conferida.

Os hashes locais dos três arquivos `.fds` coincidem com o manifesto de preparação. A cópia não veio acompanhada de um inventário remoto de hashes dos resultados; portanto, não se afirma igualdade byte a byte entre os arquivos de saída remotos e locais. Os logs locais registram a conclusão normal do FDS.

## 2. Validação usada nesta etapa

Foi feita validação cruzada deixando um cenário CFD completo de fora por rodada: seis rodadas, cinco cenários no treino e um no teste. Em cada instante, as entradas são T, visibilidade, CO e velocidade em S01, S02, S09 e S10, mais x e z do alvo. Os alvos são T, visibilidade e CO em S03–S08. Tempo, cenário, potência, ventilação e valores do alvo não entram como preditores.

Foram mantidos os parâmetros anteriores: vizinho mais próximo, interpolação longitudinal linear, Ridge (`alpha=1`) e Random Forest (100 árvores, profundidade 10, folha mínima 5). A transformação de escala do Ridge é ajustada somente no treino. Todos os métodos recebem os mesmos limites de representação e a fração de projeção é registrada. Os 3.606 pares alvo-instante por rodada são observações correlacionadas da mesma simulação; não são 3.606 incêndios independentes.

## 3. Erros médios por cenário

Cada valor abaixo é a média das seis métricas de MAE por cenário, dando o mesmo peso a cada cenário. Grandezas e unidades são mantidas separadas.

| Grandeza | Vizinho | Interpolação linear | Ridge | Random Forest |
|---|---:|---:|---:|---:|
| Temperatura (°C) | 9,86 | 9,85 | 15,22 | 30,07 |
| Visibilidade (m) | 2,97 | 3,89 | 6,81 | 4,73 |
| CO (ppm) | 3,21 | 3,67 | 4,78 | 9,62 |

O Random Forest teve MAE menor que a interpolação linear em apenas 2 das 6 rodadas para cada uma das três grandezas. O Ridge não foi melhor em temperatura em nenhuma rodada; foi melhor em visibilidade e CO em 2 de 6 rodadas para cada. O vizinho mais próximo foi melhor que a interpolação linear em 3/6 rodadas para temperatura e 4/6 para visibilidade e CO. Portanto, estes resultados não sustentam superioridade geral dos modelos de ML.

O RF teve bom resultado em P05V02 e P10V03, mas não repetiu esse desempenho em todos os cenários. Em P20V01, seu MAE de temperatura foi 109,92 °C, comparado a 14,82 °C para a interpolação linear. Na rodada que testa P20V01, 91,85% das linhas tinham pelo menos uma entrada fora dos mínimos/máximos do treino; 16 dos 18 preditores ultrapassavam a faixa de treino em algum ponto. Aproximadamente 90–91% dos valores-alvo de T, visibilidade e CO também estavam fora da faixa dos alvos de treino. Para a temperatura, o teste chegou a 261,34 °C, enquanto o máximo de treino era 105,85 °C. O RF estimou até 71,81 °C nesse caso. Isso é consistente com forte extrapolação sem suporte nos dados de treino e explica por que o RF não recupera o pico; não é erro de execução da simulação.

O Ridge teve valores alterados pelo limite de saída em uma fração expressiva de algumas rodadas: em média 34,50% das estimativas de visibilidade e 20,77% de CO foram projetadas. Em P10V03, a projeção ocorreu em 99,20% das estimativas de visibilidade e 96,51% de CO. Mesmo quando o erro pós-projeção parece baixo, essa dependência precisa ser examinada antes de interpretar o ajuste como bom comportamento do modelo.

## 4. Regra provisória de disponibilidade

Foi avaliada, apenas como diagnóstico, uma regra simples: emitir estimativa se todas as 18 entradas estiverem dentro do intervalo min–max observado nos cinco cenários de treino; caso contrário, sinalizar “estimativa indisponível”. A mesma regra foi aplicada a todos os métodos.

| Cenário testado | Cobertura da regra |
|---|---:|
| S1 | 99,83% |
| S2 | 100,00% |
| S3 | 98,67% |
| P05V02 | 100,00% |
| P10V03 | 99,50% |
| P20V01 | 8,15% |

Essa regra evita emitir resultados na maior parte dos instantes fortemente fora de faixa em P20V01, mas não resolve a validação de severidade: nos 8,15% de linhas aceitas para P20V01, o RF ainda subestimou a faixa local em 29,25% dos pares alvo-instante. A cobertura alta nos demais cenários também não garante que combinações de entradas estejam dentro de uma região conjunta conhecida. O min–max não é, portanto, uma salvaguarda validada nem pode ser chamado de limite de sensor. É um candidato transparente para estudo adicional, não uma solução já demonstrada.

## 5. Faixas de severidade metodológica

Com as faixas locais de pesquisa (T 40/80/150 °C; visibilidade 20/10/5 m; CO 50/200/800 ppm), S3, P05V02 e P10V03 foram classificados como Low em todos os 3.606 pares alvo-instante. A concordância dessas rodadas é pouco informativa sobre a distinção entre faixas. S1, S2 e P20V01 contêm as classes mais altas.

Na média simples das seis rodadas, a concordância de faixa foi 86,1% para o vizinho, 76,5% para a interpolação, 75,7% para o RF e 63,2% para o Ridge; as frações de subestimação foram, respectivamente, 5,6%, 10,2%, 15,9% e 25,1%. Essas médias descrevem a regra aplicada a saídas CFD neste conjunto e são influenciadas por rodadas inteiramente Low. Os limiares seguem a especificação de pesquisa revisada; não foram validados como critérios normativos, de tenabilidade humana, alarme ou risco probabilístico.

## 6. Decisão metodológica recomendada

Com os dados disponíveis, não recomendo apresentar Ridge ou Random Forest como núcleo superior do método. Manter os dois como comparadores, preservar os baselines simples e relatar as falhas é mais fiel aos resultados. Qualquer campo fora da aplicabilidade documentada deve ser marcado como indisponível, nunca convertido automaticamente em Low/normal.

Antes do conjunto reservado, a versão final de desenvolvimento precisa especificar: (i) se algum modelo de ML continuará como estimador ou apenas comparador; (ii) a regra de disponibilidade, aplicada também aos baselines; (iii) o tratamento das saídas afetadas por projeção; e (iv) como a camada local de severidade lidará com estimativas indisponíveis. Depois, o método deve ser congelado e P05V03, P10V01 e P20V02 avaliados uma única vez. Alterar o método após olhar esses resultados torna essa avaliação exploratória.

Mesmo uma rodada reservada favorável sustentará somente avaliação entre cenários CFD com a mesma geometria, malha e configuração geral. Não há validação experimental, nova malha, outra geometria, dados de túnel real ou ensaio operacional. A contribuição para a EAAI ainda precisa ser reavaliada: estes dados, por si sós, não demonstram avanço algorítmico nem vantagem de IA sobre interpolação.
