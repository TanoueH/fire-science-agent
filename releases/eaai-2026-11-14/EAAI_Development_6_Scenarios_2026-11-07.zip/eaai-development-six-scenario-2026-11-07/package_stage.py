"""Create a portable ZIP and SHA-256 manifest for this development stage."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent
ARCHIVE = ROOT.parent / 'EAAI_Development_6_Scenarios_2026-11-07.zip'
MANIFEST = ROOT / 'PACKAGE_MANIFEST.json'
EXCLUDE_DIRS = {'__pycache__', '.pytest_cache'}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


files = []
for path in sorted(ROOT.rglob('*')):
    if not path.is_file() or path == MANIFEST or path.suffix in {'.pyc', '.zip'}:
        continue
    if any(part in EXCLUDE_DIRS for part in path.relative_to(ROOT).parts):
        continue
    files.append({
        'path': path.relative_to(ROOT).as_posix(),
        'bytes': path.stat().st_size,
        'sha256': digest(path),
    })
MANIFEST.write_text(json.dumps({'stage': 'eaai-development-six-scenario-2026-11-07',
                                'files': files}, indent=2) + '\n', encoding='utf-8')

with zipfile.ZipFile(ARCHIVE, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
    for item in files:
        path = ROOT / Path(item['path'])
        zf.write(path, arcname=(ROOT.name + '/' + item['path']))
    zf.write(MANIFEST, arcname=(ROOT.name + '/PACKAGE_MANIFEST.json'))

with zipfile.ZipFile(ARCHIVE, 'r') as zf:
    bad_member = zf.testzip()
    if bad_member:
        raise RuntimeError(f'ZIP CRC failure: {bad_member}')
    zipped = {name.removeprefix(ROOT.name + '/'): zf.read(name)
              for name in zf.namelist() if name != ROOT.name + '/PACKAGE_MANIFEST.json'}
for item in files:
    content = zipped[item['path']]
    if hashlib.sha256(content).hexdigest() != item['sha256']:
        raise RuntimeError(f'ZIP member does not match manifest: {item["path"]}')
print(json.dumps({'archive': str(ARCHIVE), 'bytes': ARCHIVE.stat().st_size,
                  'members_verified': len(files), 'crc_check_passed': True,
                  'manifest_sha256': digest(MANIFEST)}, indent=2))
