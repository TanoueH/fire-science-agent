"""Execute the single frozen evaluation on P05V03, P10V01 and P20V02."""
from pathlib import Path
import hashlib
import json
import os
import platform
import sys
import time
import warnings

ROOT = Path(__file__).resolve().parent
PROJECT = Path(__file__).resolve().parents[2]
DEPS = PROJECT / 'output/fds-reviewed-2026-11-05/.python-deps'
if DEPS.is_dir():
    sys.path.insert(0, str(DEPS))
os.environ['OMP_NUM_THREADS'] = '1'
import numpy as np
import pandas as pd
import scipy
import sklearn
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import Ridge
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

from severity import evaluate, project_predictions, VERSION, LABELS

PROTOCOL = ROOT / 'PREHOLDOUT_PROTOCOL.md'
TRAIN_PATH = ROOT / 'data/development-device-data-long.csv'
TEST_PATH = ROOT / 'data/reserved-device-data-long.csv'
QC_PATH = ROOT / 'audit/reserved-data-qc.json'
AUDIT = ROOT / 'audit'
OUT = ROOT / 'results'
RECORD_PATH = AUDIT / 'final-holdout-record.json'
if RECORD_PATH.exists():
    raise RuntimeError('The one-time final holdout evaluation is already recorded; do not rerun.')
if not all(path.is_file() for path in (PROTOCOL, TRAIN_PATH, TEST_PATH, QC_PATH)):
    raise FileNotFoundError('Protocol, development data, reserved data or reserved QC record is missing.')

OBSERVED = ['S01', 'S02', 'S09', 'S10']
TARGETS = ['S03', 'S04', 'S05', 'S06', 'S07', 'S08']
TRAIN_SCENARIOS = ['S1', 'S2', 'S3', 'P05V02', 'P10V03', 'P20V01']
TEST_SCENARIOS = ['P05V03', 'P10V01', 'P20V02']
FIELDS = ['temperature_C', 'visibility_m', 'CO_ppm']
INPUT_FIELDS = FIELDS + ['U_m_s']
UNITS = {'temperature_C': 'C', 'visibility_m': 'm', 'CO_ppm': 'ppm'}
RF_PARAMS = {'n_estimators': 100, 'max_depth': 10, 'min_samples_leaf': 5,
             'random_state': 42, 'n_jobs': 1}
METHODS = ['nearest', 'spatial_linear', 'ridge', 'random_forest']


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


protocol_hash = sha(PROTOCOL)
qc = json.loads(QC_PATH.read_text(encoding='utf-8'))
if not qc.get('all_three_reserved_cases_passed_execution_and_data_checks'):
    raise RuntimeError('Reserved-case execution/data QC did not pass.')
if qc.get('protocol_sha256') != protocol_hash:
    raise RuntimeError('The reserved-data QC record does not match the frozen protocol.')
if qc.get('reserved_dataset', {}).get('sha256') != sha(TEST_PATH):
    raise RuntimeError('Reserved dataset hash differs from the QC record.')
if qc.get('holdout_histories_opened_after_protocol_frozen') is not True:
    raise RuntimeError('The reserved histories were not prepared after the protocol freeze.')

train = pd.read_csv(TRAIN_PATH)
test_data = pd.read_csv(TEST_PATH)
if set(train.scenario) != set(TRAIN_SCENARIOS) or set(test_data.scenario) != set(TEST_SCENARIOS):
    raise ValueError('Unexpected training or reserved scenario roster.')
if train.duplicated(['scenario', 'sensor_id', 'time_s']).any() or test_data.duplicated(['scenario', 'sensor_id', 'time_s']).any():
    raise ValueError('Duplicate scenario/site/time rows are not permitted.')
if not train.groupby(['scenario', 'sensor_id']).size().eq(601).all():
    raise ValueError('Training scenarios must each contain 601 samples per site.')
if not test_data.groupby(['scenario', 'sensor_id']).size().eq(601).all():
    raise ValueError('Reserved scenarios must each contain 601 samples per site.')
if not np.isfinite(train[INPUT_FIELDS + FIELDS + ['time_s', 'x_m', 'y_m', 'z_m']].to_numpy()).all():
    raise ValueError('Training data contain non-finite values.')
if not np.isfinite(test_data[INPUT_FIELDS + FIELDS + ['time_s', 'x_m', 'y_m', 'z_m']].to_numpy()).all():
    raise ValueError('Reserved data contain non-finite values.')


def make_case(frame):
    scenario = str(frame.scenario.iloc[0])
    times = np.sort(frame.time_s.unique())
    if len(times) != 601 or times[0] != 0 or times[-1] != 600:
        raise ValueError(f'Unexpected timeline in {scenario}')
    coords = frame.groupby('sensor_id')[['x_m', 'y_m', 'z_m']].first()
    if set(coords.index) != set(OBSERVED + TARGETS):
        raise ValueError(f'Unexpected sensor roster in {scenario}')
    wide = {field: frame.pivot(index='time_s', columns='sensor_id', values=field).reindex(index=times)
            for field in INPUT_FIELDS}
    if any(table.isna().any().any() for table in wide.values()):
        raise ValueError(f'Missing observed predictor in {scenario}')
    observed = np.column_stack([wide[field][site].to_numpy()
                                for field in INPUT_FIELDS for site in OBSERVED])
    locations = coords.loc[TARGETS, ['x_m', 'z_m']].to_numpy()
    X = np.column_stack([np.repeat(observed, len(TARGETS), axis=0),
                         np.tile(locations, (len(times), 1))])
    Y = np.column_stack([wide[field][TARGETS].to_numpy().reshape(-1) for field in FIELDS])
    nearest, spatial_linear = np.zeros_like(Y), np.zeros_like(Y)
    for j, site in enumerate(TARGETS):
        x, _, z = coords.loc[site]
        anchors = coords.loc[OBSERVED]
        anchors = anchors[anchors.z_m == z].sort_values('x_m')
        if len(anchors) != 2:
            raise ValueError(f'Expected two same-side anchors at {site}')
        left, right = anchors.index
        x0, x1 = float(anchors.iloc[0].x_m), float(anchors.iloc[1].x_m)
        if not x0 < x < x1:
            raise ValueError(f'Target site is outside observed anchors: {site}')
        fraction = (x - x0) / (x1 - x0)
        closest = left if (x - x0) <= (x1 - x) else right
        for k, field in enumerate(FIELDS):
            nearest[j::len(TARGETS), k] = wide[field][closest].to_numpy()
            spatial_linear[j::len(TARGETS), k] = (
                (1 - fraction) * wide[field][left].to_numpy()
                + fraction * wide[field][right].to_numpy()
            )
    meta = pd.DataFrame({
        'scenario': scenario, 'time_s': np.repeat(times, len(TARGETS)),
        'target_site': np.tile(TARGETS, len(times)),
        'x_m': np.tile(locations[:, 0], len(times)), 'z_m': np.tile(locations[:, 1], len(times)),
    })
    if X.shape != (3606, 18) or Y.shape != (3606, 3):
        raise ValueError(f'Unexpected feature/target shape in {scenario}')
    return {'X': X, 'Y': Y, 'meta': meta,
            'nearest': nearest, 'spatial_linear': spatial_linear}


def errors(y, pred):
    if len(y) == 0:
        return {'MAE': None, 'RMSE': None, 'max_absolute_error': None, 'bias': None, 'R2': None}
    err = pred - y
    denom = float(np.sum((y - y.mean()) ** 2))
    return {'MAE': float(np.abs(err).mean()), 'RMSE': float(np.sqrt(np.mean(err ** 2))),
            'max_absolute_error': float(np.abs(err).max()), 'bias': float(err.mean()),
            'R2': float(1 - np.sum(err ** 2) / denom) if denom > 1e-12 else None}


train_cases = {name: make_case(train[train.scenario == name]) for name in TRAIN_SCENARIOS}
test_cases = {name: make_case(test_data[test_data.scenario == name]) for name in TEST_SCENARIOS}
X_train = np.concatenate([train_cases[name]['X'] for name in TRAIN_SCENARIOS])
Y_train = np.concatenate([train_cases[name]['Y'] for name in TRAIN_SCENARIOS])
if X_train.shape != (21636, 18) or Y_train.shape != (21636, 3):
    raise ValueError('Training set does not match the frozen 21,636-row design.')
X_min, X_max = X_train.min(axis=0), X_train.max(axis=0)
FEATURES = [field + '@' + site for field in INPUT_FIELDS for site in OBSERVED] + ['target_x_m', 'target_z_m']
if len(FEATURES) != 18:
    raise ValueError('Unexpected feature list.')

OUT.mkdir(parents=True, exist_ok=True)
metric_rows, band_rows, prediction_frames, fit_log, warnings_log, range_rows = [], [], [], [], [], []
start = time.perf_counter()

for scenario in TEST_SCENARIOS:
    case = test_cases[scenario]
    X_test, Y_test = case['X'], case['Y']
    supported = np.all((X_test >= X_min) & (X_test <= X_max), axis=1)
    meta = case['meta'].copy()
    meta['inside_training_feature_minmax'] = supported
    support_rows = int(supported.sum())
    actual_severity = evaluate(Y_test)

    raw_predictions = {}
    for method in METHODS:
        fit_start = time.perf_counter()
        if method in ('nearest', 'spatial_linear'):
            raw = case[method].copy()
        else:
            per_field = []
            for k, field in enumerate(FIELDS):
                if method == 'ridge':
                    model = make_pipeline(StandardScaler(), Ridge(alpha=1.0))
                else:
                    model = RandomForestRegressor(**RF_PARAMS)
                with warnings.catch_warnings(record=True) as caught:
                    warnings.simplefilter('always')
                    model.fit(X_train, Y_train[:, k])
                    per_field.append(model.predict(X_test))
                warnings_log.extend({
                    'test_scenario': scenario, 'method': method, 'quantity': field,
                    'category': item.category.__name__, 'message': str(item.message),
                } for item in caught)
            raw = np.column_stack(per_field)
        if not np.isfinite(raw).all():
            raise ValueError(f'Non-finite predictions from {method} on {scenario}')
        projected, clipped = project_predictions(raw)
        raw_predictions[method] = {'raw': raw, 'projected': projected, 'clipped': clipped}
        fit_log.append({'test_scenario': scenario, 'method': method,
                        'fit_predict_seconds': float(time.perf_counter() - fit_start),
                        'n_training_rows': int(len(X_train)), 'n_test_rows': int(len(X_test))})

    for method in METHODS:
        raw = raw_predictions[method]['raw']
        projected = raw_predictions[method]['projected']
        clipped = raw_predictions[method]['clipped']
        for k, field in enumerate(FIELDS):
            clip_fraction = float(clipped[:, k].mean())
            for representation, pred in [('raw', raw), ('projected', projected)]:
                for subset, mask in [('all_rows', np.ones(len(Y_test), dtype=bool)),
                                     ('inside_training_feature_minmax', supported),
                                     ('outside_training_feature_minmax', ~supported)]:
                    metric_rows.append({
                        'test_scenario': scenario, 'method': method, 'quantity': field,
                        'unit': {'temperature_C': 'C', 'visibility_m': 'm', 'CO_ppm': 'ppm'}[field],
                        'prediction_representation': representation, 'subset': subset,
                        'n_temporal_spatial_rows': int(mask.sum()),
                        'support_coverage': support_rows / len(Y_test),
                        'projection_fraction_in_full_case': clip_fraction,
                        'projection_fraction_in_subset': float(clipped[mask, k].mean()) if mask.any() else None,
                        **errors(Y_test[mask, k], pred[mask, k]),
                    })

        # Risk-band estimates are defined only on supported, projected outputs.
        if supported.any():
            predicted_severity = evaluate(projected[supported])
            ref_band = actual_severity['band'][supported]
            est_band = predicted_severity['band']
            elevated, critical = ref_band > 0, ref_band == 3
            band_rows.append({
                'test_scenario': scenario, 'method': method,
                'available_pairs': support_rows, 'all_pairs': int(len(Y_test)),
                'availability_fraction': support_rows / len(Y_test),
                'reference_Low_all_rows': int((actual_severity['band'] == 0).sum()),
                'reference_Medium_all_rows': int((actual_severity['band'] == 1).sum()),
                'reference_High_all_rows': int((actual_severity['band'] == 2).sum()),
                'reference_Critical_all_rows': int((actual_severity['band'] == 3).sum()),
                'band_agreement_on_available_pairs': float((ref_band == est_band).mean()),
                'underestimated_band_fraction_on_available_pairs': float((est_band < ref_band).mean()),
                'overestimated_band_fraction_on_available_pairs': float((est_band > ref_band).mean()),
                'low_estimate_given_elevated_reference_fraction': float((est_band[elevated] == 0).mean()) if elevated.any() else None,
                'missed_critical_reference_fraction': float((est_band[critical] < 3).mean()) if critical.any() else None,
                'gradual_indicator_MAE_on_available_pairs': float(np.abs(
                    actual_severity['indicator'][supported] - predicted_severity['indicator']).mean()),
                **{'available_reference_' + LABELS[i]: int((ref_band == i).sum()) for i in range(4)},
                **{'available_estimated_' + LABELS[i]: int((est_band == i).sum()) for i in range(4)},
            })
        else:
            band_rows.append({'test_scenario': scenario, 'method': method,
                              'available_pairs': 0, 'all_pairs': int(len(Y_test)),
                              'availability_fraction': 0.0,
                              'band_agreement_on_available_pairs': None,
                              'underestimated_band_fraction_on_available_pairs': None,
                              'overestimated_band_fraction_on_available_pairs': None})

        frame = meta.copy()
        frame['method'] = method
        for k, field in enumerate(FIELDS):
            frame['reference_' + field] = Y_test[:, k]
            frame['raw_' + field] = raw[:, k]
            frame['projected_' + field] = projected[:, k]
            frame['was_projected_' + field] = clipped[:, k]
        frame['reference_local_band'] = actual_severity['band']
        frame['predicted_local_band_available_only'] = np.nan
        if supported.any():
            frame.loc[supported, 'predicted_local_band_available_only'] = evaluate(projected[supported])['band']
        frame['reference_gradual_indicator'] = actual_severity['indicator']
        frame['predicted_gradual_indicator_available_only'] = np.nan
        if supported.any():
            frame.loc[supported, 'predicted_gradual_indicator_available_only'] = evaluate(projected[supported])['indicator']
        prediction_frames.append(frame)

    # Feature-by-feature range diagnostic, independent of method.
    for j, feature in enumerate(FEATURES):
        outside = (X_test[:, j] < X_min[j]) | (X_test[:, j] > X_max[j])
        range_rows.append({
            'test_scenario': scenario, 'feature': feature,
            'training_min': float(X_min[j]), 'training_max': float(X_max[j]),
            'test_min': float(X_test[:, j].min()), 'test_max': float(X_test[:, j].max()),
            'fraction_test_rows_outside_training_minmax': float(outside.mean()),
        })
    print(json.dumps({'test_scenario': scenario, 'support_coverage': support_rows / len(Y_test),
                      'methods_completed': METHODS}, ensure_ascii=False), flush=True)

metric_df = pd.DataFrame(metric_rows)
band_df = pd.DataFrame(band_rows)
prediction_df = pd.concat(prediction_frames, ignore_index=True)
range_df = pd.DataFrame(range_rows)
metric_df.to_csv(OUT / 'reserved-metrics.csv', index=False)
band_df.to_csv(OUT / 'reserved-severity-metrics.csv', index=False)
prediction_df.to_csv(OUT / 'reserved-predictions.csv', index=False)
range_df.to_csv(AUDIT / 'reserved-predictor-ranges.csv', index=False)
pd.DataFrame(warnings_log, columns=['test_scenario', 'method', 'quantity', 'category', 'message']).to_csv(
    AUDIT / 'reserved-model-warnings.csv', index=False)

primary = metric_df[(metric_df.prediction_representation == 'projected') & (metric_df.subset == 'all_rows')]
summary = primary.groupby(['method', 'quantity'], as_index=False).agg(
    mean_case_MAE=('MAE', 'mean'), mean_case_RMSE=('RMSE', 'mean'),
    worst_case_MAE=('MAE', 'max'), mean_projection_fraction=('projection_fraction_in_full_case', 'mean'))
summary.to_csv(OUT / 'reserved-summary-all-rows.csv', index=False)
support_primary = metric_df[(metric_df.prediction_representation == 'projected') &
                            (metric_df.subset == 'inside_training_feature_minmax')]
support_summary = support_primary.groupby(['method', 'quantity'], as_index=False).agg(
    mean_case_supported_MAE=('MAE', 'mean'), worst_case_supported_MAE=('MAE', 'max'),
    mean_case_support_coverage=('support_coverage', 'mean'))
support_summary.to_csv(OUT / 'reserved-summary-supported-rows.csv', index=False)

comparison = primary.merge(
    primary[primary.method == 'spatial_linear'][['test_scenario', 'quantity', 'MAE']]
    .rename(columns={'MAE': 'spatial_linear_MAE'}),
    on=['test_scenario', 'quantity'], validate='many_to_one')
comparison['MAE_difference_vs_spatial_linear'] = comparison.MAE - comparison.spatial_linear_MAE
comparison.to_csv(OUT / 'reserved-comparison-with-spatial-linear.csv', index=False)

record = {
    'stage': 'single_frozen_reserved_evaluation',
    'date': '2026-11-07', 'protocol_sha256': protocol_hash,
    'development_data_sha256': sha(TRAIN_PATH), 'reserved_data_sha256': sha(TEST_PATH),
    'benchmark_script_sha256': sha(Path(__file__)),
    'severity_script_sha256': sha(ROOT / 'severity.py'),
    'reserved_input_file_manifest_sha256': sha(AUDIT / 'reserved-data-qc.json'),
    'environment': {'python': platform.python_version(), 'numpy': np.__version__,
                    'pandas': pd.__version__, 'scipy': scipy.__version__,
                    'scikit_learn': sklearn.__version__},
    'training_scenarios': TRAIN_SCENARIOS, 'reserved_scenarios': TEST_SCENARIOS,
    'training_rows': int(len(X_train)), 'test_rows_per_case': 3606,
    'model_fits': {'ridge': 9, 'random_forest': 9},
    'all_four_methods_reported': True, 'all_scenarios_reported': True,
    'strict_training_minmax_screen_applied_equally': True,
    'unsupported_estimates_have_no_severity_band': True,
    'raw_and_projected_regression_metrics_reported': True,
    'warnings': warnings_log, 'fitting_log': fit_log,
    'physical_validation_complete': False,
    'independent_tunnel_geometry_validation_complete': False,
    'method_changed_after_reserved_results': False,
    'interpretation': 'CFD scenario generalization in the same geometry/configuration only; no operational safety validation.',
    'elapsed_seconds': float(time.perf_counter() - start),
}
RECORD_PATH.write_text(json.dumps(record, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')

lines = [
    '# Avaliação final dos três cenários reservados', '',
    'Protocolo congelado em `PREHOLDOUT_PROTOCOL.md`; não houve ajuste de hiperparâmetros nem escolha de método após abrir os resultados. '
    'As métricas completas incluem diagnóstico de extrapolação; a faixa local estimada só é calculada quando as 18 entradas estão '
    'dentro do suporte min–max do treino. Fora dele, a classe estimada fica indisponível.', '',
    '## MAE após projeção de limites, em todos os pares (inclui extrapolação)', '',
    '| Método | Grandeza | Média por cenário | Pior cenário | Fração média projetada |',
    '|---|---|---:|---:|---:|',
]
for row in summary.sort_values(['quantity', 'method']).to_dict(orient='records'):
    unit = {'temperature_C': '°C', 'visibility_m': 'm', 'CO_ppm': 'ppm'}[row['quantity']]
    lines.append(f"| {row['method']} | {row['quantity']} | {row['mean_case_MAE']:.6g} {unit} | "
                 f"{row['worst_case_MAE']:.6g} {unit} | {row['mean_projection_fraction']:.3%} |")
lines += ['', '## Cobertura por cenário', '', '| Cenário | Pares disponíveis / 3606 | Cobertura |', '|---|---:|---:|']
for scenario in TEST_SCENARIOS:
    count = int(prediction_df[(prediction_df.scenario == scenario) & (prediction_df.method == 'nearest')]
                .inside_training_feature_minmax.sum())
    lines.append(f'| {scenario} | {count} / 3606 | {count / 3606:.2%} |')
lines += ['', '## Severidade local nas previsões disponíveis', '',
          'Os números abaixo são comparações com faixas de pesquisa aplicadas aos resultados CFD; não são desempenho de alarme ou risco humano.', '',
          '| Cenário | Método | Cobertura | Concordância | Subestimação |', '|---|---|---:|---:|---:|']
for row in band_df.to_dict(orient='records'):
    agreement = '—' if pd.isna(row.get('band_agreement_on_available_pairs')) else f"{row['band_agreement_on_available_pairs']:.2%}"
    under = '—' if pd.isna(row.get('underestimated_band_fraction_on_available_pairs')) else f"{row['underestimated_band_fraction_on_available_pairs']:.2%}"
    lines.append(f"| {row['test_scenario']} | {row['method']} | {row['availability_fraction']:.2%} | {agreement} | {under} |")
lines += ['', 'Cada caso permanece uma simulação CFD; os pontos temporais e espaciais não são réplicas independentes. '
          'Esta avaliação não demonstra validade experimental, em outra malha/geometria, nem para segurança humana ou operação real.', '']
(OUT / 'FINAL_HOLDOUT_REPORT.md').write_text('\n'.join(lines), encoding='utf-8')

print(json.dumps({
    'completed_once': True, 'protocol_sha256': protocol_hash,
    'metrics_rows': len(metric_df), 'severity_rows': len(band_df),
    'prediction_rows': len(prediction_df), 'model_fits': record['model_fits'],
    'warnings': len(warnings_log), 'support_coverage': [
        {'scenario': scenario,
         'coverage': float(prediction_df[(prediction_df.scenario == scenario) &
                                         (prediction_df.method == 'nearest')]
                           .inside_training_feature_minmax.mean())}
        for scenario in TEST_SCENARIOS],
}, indent=2, ensure_ascii=False))
