"""Audit and prepare the three reserved CFD outputs under the frozen protocol."""
from pathlib import Path
import csv
import hashlib
import json
import math
import re
import shutil
import sys

ROOT = Path(__file__).resolve().parent
PROJECT = Path(__file__).resolve().parents[2]
FACTORIAL = PROJECT / 'output/fds-factorial-2026-11-05'
SOURCE = FACTORIAL / 'cenapad-download/holdout'
HASH_FILE = ROOT / 'data/source-input-sha256sums.txt'
TRAIN = ROOT / 'data/development-device-data-long.csv'
DEST = ROOT / 'data/raw-reserved-cases'
OUT = ROOT / 'data/reserved-device-data-long.csv'
AUDIT = ROOT / 'audit/reserved-data-qc.json'
CASES = {
    'P05V03': {'power_MW': 5, 'inlet_normal_VEL_m_s': -3.0},
    'P10V01': {'power_MW': 10, 'inlet_normal_VEL_m_s': -1.0},
    'P20V02': {'power_MW': 20, 'inlet_normal_VEL_m_s': -2.0},
}
SITES = [f'S{i:02d}' for i in range(1, 11)]

if not (ROOT / 'PREHOLDOUT_PROTOCOL.md').is_file():
    raise FileNotFoundError('The frozen pre-holdout protocol is required.')
if (ROOT / 'audit/final-holdout-record.json').exists():
    raise RuntimeError('A final holdout evaluation record already exists; do not run this stage again.')
if not TRAIN.is_file() or not HASH_FILE.is_file():
    raise FileNotFoundError('The development dataset or prepared input hash list is missing.')

import numpy as np
import pandas as pd


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def parse_hashes(path):
    result = {}
    for line in path.read_text(encoding='utf-8').splitlines():
        match = re.match(r'([0-9a-f]{64})  (.+)$', line)
        if match:
            result[match.group(2)] = match.group(1)
    return result


def copy_needed_files(case, prefix):
    source_dir = SOURCE / case
    local_dir = DEST / case
    local_dir.mkdir(parents=True, exist_ok=True)
    name_map = {
        'input_fds': (source_dir / f'{prefix}.fds', local_dir / f'{case}.fds'),
        'devc_csv': (source_dir / f'{prefix}_devc.csv', local_dir / f'{case}_devc.csv'),
        'hrr_csv': (source_dir / f'{prefix}_hrr.csv', local_dir / f'{case}_hrr.csv'),
        'steps_csv': (source_dir / f'{prefix}_steps.csv', local_dir / f'{case}_steps.csv'),
        'out': (source_dir / f'{prefix}.out', local_dir / f'{case}.out'),
        'console_log': (source_dir / 'console.log', local_dir / f'{case}.log'),
    }
    manifest = {}
    for kind, (source_path, local_path) in name_map.items():
        if not source_path.is_file():
            raise FileNotFoundError(f'Missing reserved-case file: {source_path}')
        if local_path.exists() and sha(local_path) != sha(source_path):
            raise RuntimeError(f'Previously copied file differs: {local_path}')
        if not local_path.exists():
            shutil.copy2(source_path, local_path)
        manifest[kind] = {'path': str(local_path.relative_to(ROOT)), 'sha256': sha(local_path),
                          'bytes': local_path.stat().st_size}
    return {key: pair[1] for key, pair in name_map.items()}, manifest


def read_units(path):
    with path.open('r', encoding='utf-8-sig', newline='') as stream:
        reader = csv.reader(stream)
        unit_row, header = next(reader), next(reader)
    if len(unit_row) != len(header):
        raise ValueError(f'Units and header widths differ: {path}')
    return dict(zip(header, unit_row))


def coordinates(path):
    text = path.read_text(encoding='utf-8', errors='replace')
    pattern = re.compile(
        r"ID=['\"](?:T|VIS|CO|U)_(S\d{2})['\"]\s*,\s*XYZ=\s*"
        r"([-+0-9.eE]+)\s*,\s*([-+0-9.eE]+)\s*,\s*([-+0-9.eE]+)", re.I)
    found = {}
    for site, x, y, z in pattern.findall(text):
        xyz = tuple(float(value) for value in (x, y, z))
        if site in found and found[site] != xyz:
            raise ValueError(f'Inconsistent coordinates for {site}')
        found[site] = xyz
    if set(found) != set(SITES):
        raise ValueError(f'Expected coordinates for S01-S10; got {sorted(found)}')
    return found, text


def main():
    prepared = parse_hashes(HASH_FILE)
    training = pd.read_csv(TRAIN)
    train_coords = training.groupby('sensor_id')[['x_m', 'y_m', 'z_m']].first()
    all_new, reviews, file_manifest = [], [], {}
    for case, spec in CASES.items():
        prefix = f'eaai20261105_{case}_yup_600s'
        files, file_manifest[case] = copy_needed_files(case, prefix)
        input_rel = f'cases/holdout/{case}/{prefix}.fds'
        input_hash = sha(files['input_fds'])
        if input_hash != prepared.get(input_rel):
            raise ValueError(f'Input hash differs from the reviewed preparation for {case}')
        coords, input_text = coordinates(files['input_fds'])
        for site, xyz in coords.items():
            expected_xyz = tuple(train_coords.loc[site, ['x_m', 'y_m', 'z_m']].astype(float))
            if xyz != expected_xyz:
                raise ValueError(f'Sensor geometry differs from training layout at {case}/{site}')
        if not re.search(r'TMPA\s*=\s*20(?:\.0+)?', input_text):
            raise ValueError(f'Unexpected ambient temperature input in {case}')
        if not re.search(r'GVEC\s*=\s*0(?:\.0*)?\s*,\s*-9\.81\s*,\s*0(?:\.0*)?', input_text):
            raise ValueError(f'Unexpected gravity vector in {case}')
        inlet_id = f"INFLOW_{int(abs(spec['inlet_normal_VEL_m_s']))}MS"
        inlet = re.search(rf"ID=['\"]{inlet_id}['\"](.*?)/", input_text, re.S)
        velocity = re.search(r'VEL\s*=\s*([-+0-9.eE]+)', inlet.group(1)) if inlet else None
        if not velocity or not math.isclose(float(velocity.group(1)), spec['inlet_normal_VEL_m_s'], abs_tol=1e-12):
            raise ValueError(f'Unexpected inlet velocity in {case}')

        unit_map = read_units(files['devc_csv'])
        if unit_map.get('Time') != 's':
            raise ValueError(f'Unexpected Time unit in {case}')
        for site in SITES:
            for column, unit in ((f'T_{site}', 'C'), (f'VIS_{site}', 'm'),
                                 (f'CO_{site}', 'mol/mol'), (f'U_{site}', 'm/s')):
                if unit_map.get(column) != unit:
                    raise ValueError(f'Unexpected unit for {column} in {case}: {unit_map.get(column)}')
        raw = pd.read_csv(files['devc_csv'], skiprows=1)
        expected_columns = ['Time'] + [f'{channel}_{site}' for site in SITES
                                       for channel in ('T', 'VIS', 'CO', 'U')]
        if any(column not in raw.columns for column in expected_columns):
            raise ValueError(f'Missing DEVC columns in {case}')
        times = raw['Time'].to_numpy(dtype=float)
        values = raw[expected_columns].to_numpy(dtype=float)
        if len(times) != 601 or times[0] != 0 or times[-1] != 600 or not np.all(np.diff(times) > 0):
            raise ValueError(f'DEVC time coverage/order is invalid in {case}')
        if not np.isfinite(values).all():
            raise ValueError(f'Non-finite DEVC values in {case}')

        hrr_units = read_units(files['hrr_csv'])
        if hrr_units.get('HRR') != 'kW':
            raise ValueError(f'HRR must be reported in kW in {case}')
        hrr = pd.read_csv(files['hrr_csv'], skiprows=1)
        hrr_window = hrr.loc[(hrr.Time >= 300) & (hrr.Time <= 600), 'HRR']
        actual_mw = float(hrr_window.mean()) / 1000
        if len(hrr) != 121 or float(hrr.Time.iloc[-1]) != 600:
            raise ValueError(f'HRR coverage is invalid in {case}')
        if abs(actual_mw - spec['power_MW']) / spec['power_MW'] > 0.05:
            raise ValueError(f'Achieved HRR differs from nominal by more than 5% in {case}')
        steps = pd.read_csv(files['steps_csv'], skiprows=1)
        if 'Simulation Time' not in steps or not math.isclose(float(steps['Simulation Time'].iloc[-1]), 600.0, abs_tol=1e-6):
            raise ValueError(f'Step output does not end at 600 s in {case}')

        out_text = files['out'].read_text(encoding='utf-8', errors='replace')
        log_text = files['console_log'].read_text(encoding='utf-8', errors='replace')
        if 'FDS-6.8.0' not in out_text or 'Ambient Temperature (C)' not in out_text or '20.00' not in out_text:
            raise ValueError(f'Unexpected FDS revision or ambient temperature in {case}')
        if 'STOP: FDS completed successfully' not in log_text or '600.00 s' not in log_text:
            raise ValueError(f'FDS completion or final time not recorded for {case}')

        case_rows = []
        for site in SITES:
            x, y, z = coords[site]
            for i, time_s in enumerate(times):
                case_rows.append({
                    'scenario': case, 'CHID': prefix, 'sensor_id': site, 'time_s': time_s,
                    'x_m': x, 'y_m': y, 'z_m': z,
                    'temperature_C': float(raw[f'T_{site}'].iloc[i]),
                    'visibility_m': float(raw[f'VIS_{site}'].iloc[i]),
                    'CO_ppm': float(raw[f'CO_{site}'].iloc[i]) * 1_000_000.0,
                    'U_m_s': float(raw[f'U_{site}'].iloc[i]),
                    'declared_HRR_MW': spec['power_MW'], 'configured_HRR_MW': actual_mw,
                    'inlet_normal_VEL_m_s': spec['inlet_normal_VEL_m_s'],
                })
        all_new.append(pd.DataFrame(case_rows))
        reviews.append({
            'case': case, 'input_sha256_matches_preparation': True,
            'FDS_revision': 'FDS-6.8.0', 'ambient_C': 20.0,
            'gravity_vector': [0.0, -9.81, 0.0],
            'inlet_normal_velocity_m_s': spec['inlet_normal_VEL_m_s'],
            'DEVC_rows': len(raw), 'DEVC_columns': len(raw.columns),
            'DEVC_start_s': float(times[0]), 'DEVC_end_s': float(times[-1]),
            'all_DEVC_values_finite': True,
            'HRR_rows': len(hrr), 'HRR_end_s': float(hrr.Time.iloc[-1]),
            'mean_HRR_300_600_MW': actual_mw,
            'relative_HRR_difference_percent': 100 * (actual_mw - spec['power_MW']) / spec['power_MW'],
            'steps_end_s': float(steps['Simulation Time'].iloc[-1]),
            'console_success_and_600_s': True,
        })

    reserved = pd.concat(all_new, ignore_index=True)
    if reserved.isna().any().any() or not np.isfinite(reserved.select_dtypes(include=[np.number]).to_numpy()).all():
        raise ValueError('Reserved dataset contains missing or non-finite values')
    if len(reserved) != 3 * 10 * 601 or reserved.duplicated(['scenario', 'sensor_id', 'time_s']).any():
        raise ValueError('Unexpected reserved dataset dimensions or duplicate rows')
    if not reserved.groupby(['scenario', 'sensor_id']).size().eq(601).all():
        raise ValueError('Expected 601 samples for every reserved sensor')
    if (reserved['visibility_m'] < 0).any() or (reserved['CO_ppm'] < 0).any():
        raise ValueError('Negative visibility or CO value in reserved cases')
    reserved.to_csv(OUT, index=False, float_format='%.12g')
    record = {
        'stage': 'frozen_reserved_holdout_preparation',
        'protocol_sha256': sha(ROOT / 'PREHOLDOUT_PROTOCOL.md'),
        'reserved_dataset': {'path': str(OUT.relative_to(ROOT)), 'sha256': sha(OUT), 'rows': len(reserved)},
        'new_reserved_raw_files': file_manifest,
        'remote_output_hash_inventory_available_for_bytewise_comparison': False,
        'cases': reviews,
        'all_three_reserved_cases_passed_execution_and_data_checks': True,
        'holdout_histories_opened_after_protocol_frozen': True,
        'physical_validation_complete': False,
    }
    AUDIT.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(record, indent=2))


if __name__ == '__main__':
    main()
