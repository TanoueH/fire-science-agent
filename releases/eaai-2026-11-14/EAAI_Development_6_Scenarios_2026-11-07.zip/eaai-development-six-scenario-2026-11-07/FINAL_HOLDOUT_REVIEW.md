# Revisão da avaliação reservada

**Data:** 7 de novembro de 2026  
**Estado:** avaliação final única conforme `PREHOLDOUT_PROTOCOL.md`; os modelos não foram retunados após abertura dos reservados.

## 1. Conferência dos três cenários

| Caso | Hash da entrada confere | Solver/saída | Velocidade normal de entrada | HRR média, 300–600 s |
|---|---:|---|---:|---:|
| P05V03 | Sim | FDS 6.8.0; conclusão em 600 s | −3 m/s | 5,00039 MW |
| P10V01 | Sim | FDS 6.8.0; conclusão em 600 s | −1 m/s | 10,00083 MW |
| P20V02 | Sim | FDS 6.8.0; conclusão em 600 s | −2 m/s | 20,00321 MW |

Cada caso tem 601 instantes DEVC entre 0 e 600 s, 47 colunas incluindo tempo, 121 registros de HRR e valores finitos. O ambiente é 20 °C, a gravidade é `(0, −9.81, 0)` e a geometria dos dez locais coincide com a usada no treino. As entradas `.fds` conferem com o manifesto de hashes preparado. Não havia hashes remotos dos resultados para verificar igualdade byte a byte da transferência; a conclusão se apoia nos arquivos locais, nos logs e na conferência dos inputs.

## 2. Protocolo aplicado

Treino somente nos seis cenários já classificados como desenvolvimento: S1, S2, S3, P05V02, P10V03 e P20V01. Foram usados 21.636 pares alvo-instante no treino e 3.606 pares em cada caso reservado. Os quatro métodos foram executados sem busca de parâmetros: vizinho longitudinal mais próximo, interpolação linear, Ridge (`alpha=1`) e Random Forest (100 árvores, profundidade 10, folha mínima 5). Houve nove ajustes Ridge, nove Random Forest e nenhum aviso de modelo.

A disponibilidade foi determinada pela regra estrita min–max aplicada às 18 entradas e igualmente aos quatro métodos. A cobertura foi 99,83% em P05V03 e 100% em P10V01 e P20V02. Para regressão, foram guardadas métricas brutas e após projeção aos limites físicos. As faixas locais de severidade foram calculadas somente nos pares disponíveis e com saídas projetadas; fora do suporte, a faixa fica indisponível.

## 3. Reconstrução contínua

MAE médio por caso, dando peso igual aos três cenários. Para Ridge, as duas colunas mostram o efeito dos limites físicos; para os outros métodos elas coincidem.

| Método | Grandeza | MAE bruto médio | MAE após projeção | Pior MAE projetado | Fração média projetada |
|---|---|---:|---:|---:|---:|
| Vizinho | Temperatura (°C) | 7,586 | 7,586 | 12,755 | 0,00% |
| Interpolação linear | Temperatura (°C) | 5,488 | 5,488 | 9,181 | 0,00% |
| Ridge | Temperatura (°C) | 7,800 | 7,800 | 10,242 | 0,00% |
| Random Forest | Temperatura (°C) | 9,345 | 9,345 | 15,245 | 0,00% |
| Vizinho | Visibilidade (m) | 0,645 | 0,645 | 1,213 | 0,00% |
| Interpolação linear | Visibilidade (m) | 0,650 | 0,650 | 1,288 | 0,00% |
| Ridge | Visibilidade (m) | 3,028 | 1,965 | 3,252 | 37,98% |
| Random Forest | Visibilidade (m) | 0,369 | 0,369 | 0,659 | 0,00% |
| Vizinho | CO (ppm) | 2,687 | 2,687 | 4,488 | 0,00% |
| Interpolação linear | CO (ppm) | 2,348 | 2,348 | 3,553 | 0,00% |
| Ridge | CO (ppm) | 2,803 | 2,050 | 3,585 | 24,98% |
| Random Forest | CO (ppm) | 3,545 | 3,545 | 5,700 | 0,00% |

Comparando MAE projetado com interpolação linear, o Random Forest foi melhor em 1/3 casos para temperatura, 2/3 para visibilidade e 0/3 para CO. O Ridge foi melhor em 1/3 para temperatura, 0/3 para visibilidade e 1/3 para CO. O vizinho e a interpolação também alternam em erros por cenário. Não há um método de ML que domine as referências simples nas três grandezas.

### Efeito importante da projeção

No caso P05V03, 99,67% das saídas Ridge de visibilidade e 72,55% das de CO foram modificadas pelos limites. O MAE de visibilidade caiu de 3,049 m bruto para 0,019 m projetado; o de CO caiu de 2,277 ppm para 0,048 ppm. Como essa rodada tem alvos praticamente todos em baixa exposição, a projeção aproxima as saídas dos limites de representação e produz erro pós-projeção pequeno. Isso não demonstra que o Ridge aprendeu bem esses campos. As métricas brutas devem acompanhar as projetadas em qualquer texto ou tabela.

## 4. Faixas locais de severidade

Distribuição das referências CFD: P05V03 tem 3.606/3.606 pares Low; P10V01 tem 3.289/3.606 Critical (91,2%); P20V02 tem 3.218/3.606 Critical (89,2%). A concordância alta em P05V03 é trivial por haver apenas uma classe. Nos outros cenários, a prevalência de Critical influencia a concordância total, por isso a subestimação também é mostrada.

| Cenário | Método | Concordância em pares disponíveis | Subestimação da faixa |
|---|---|---:|---:|
| P05V03 | Vizinho | 100,00% | 0,00% |
| P05V03 | Interpolação linear | 100,00% | 0,00% |
| P05V03 | Ridge | 99,94% | 0,00% |
| P05V03 | Random Forest | 100,00% | 0,00% |
| P10V01 | Vizinho | 96,31% | 2,38% |
| P10V01 | Interpolação linear | 96,73% | 2,44% |
| P10V01 | Ridge | 68,16% | 31,72% |
| P10V01 | Random Forest | 98,64% | 0,83% |
| P20V02 | Vizinho | 95,48% | 3,16% |
| P20V02 | Interpolação linear | 91,15% | 5,41% |
| P20V02 | Ridge | 58,18% | 39,10% |
| P20V02 | Random Forest | 95,59% | 2,80% |

O RF teve a maior concordância nos dois cenários com classes variadas; o Ridge subestimou com frequência alta nos dois. Ainda assim, essas são classes de uma especificação local de pesquisa (T 40/80/150 °C, visibilidade 20/10/5 m, CO 50/200/800 ppm), não limites validados para alarme, tenabilidade, segurança humana ou risco probabilístico.

## 5. Interpretação científica e editorial

Os reservados mostram que o RF generaliza bem para a camada local de faixas nos dois casos mais críticos, mas não é o melhor reconstrutor de temperatura ou CO. A visibilidade é sua vantagem mais consistente. O Ridge é instável para a classificação local e suas métricas de regressão são sensíveis à projeção. A interpolação linear mantém o menor MAE médio de temperatura e CO, enquanto o RF tem o menor MAE médio de visibilidade.

Minha recomendação para o manuscrito é apresentar uma comparação reprodutível de ML com baselines espaciais, explicitar a regra de indisponibilidade e relatar a falha do Ridge e a dependência dos limites de saída. Não afirmar superioridade geral de IA nem transformar as faixas em risco real. O conjunto reservado fortalece a avaliação por condições CFD não usadas no treino, mas não fornece validação experimental, independente de malha ou de geometria. A adequação à EAAI continua incerta: os resultados apoiam uma avaliação aplicada cuidadosa, mas não demonstram, por si sós, inovação algorítmica.
