# Protocolo congelado para os três cenários reservados

Data do congelamento: 7 de novembro de 2026. Esta especificação deve ser executada sem ajuste posterior aos resultados de P05V03, P10V01 e P20V02.

## Separação

- Treino: somente S1, S2, S3, P05V02, P10V03 e P20V01, já incluídos no dataset de desenvolvimento.
- Avaliação reservada: P05V03, P10V01 e P20V02; não incorporar suas saídas ao treino, escalas ou decisões de método.
- Ajustar três regressões independentes para T, visibilidade e CO. Treino com os seis cenários completos: 21.636 pares alvo-instante.

## Entradas, alvos e métodos

Manter as entradas, saídas, locais, conversão de CO e regras registradas em `PROTOCOL_DEV.md`. Não usar potência, velocidade de ventilação, identificador do cenário, tempo ou leitura do alvo como preditores.

Comparar exatamente: (1) vizinho longitudinal mais próximo do mesmo lado; (2) interpolação linear entre os dois sensores observados do mesmo lado; (3) Ridge com `StandardScaler` ajustado nos seis cenários de treino e `alpha=1`; (4) Random Forest com 100 árvores, profundidade máxima 10, folha mínima 5, `random_state=42`, `n_jobs=1`. Não escolher um método depois de observar os casos reservados e não ajustar hiperparâmetros.

## Limites e disponibilidade

Para cada par instante-alvo, verificar se todos os 18 preditores estão entre o mínimo e o máximo do treino. Aplicar a mesma máscara a todos os quatro métodos. Fora dessa faixa, a estimativa e a faixa de severidade estimada são `indisponíveis`; nunca atribuir Low/normal por falta de suporte. Reportar cobertura por caso e grandeza. Este é um filtro exploratório de suporte por variável, não uma garantia de domínio conjunto ou de segurança.

## Métricas e projeções

Calcular e reportar MAE, RMSE, erro absoluto máximo, viés e R² quando definido em dois formatos: valores brutos do algoritmo e valores depois dos limites de representação já usados (T >= -273,15 °C; visibilidade entre 0 e 30 m; CO entre 0 e 10⁶ ppm). Reportar a fração de projeção por grandeza. Métricas em todas as linhas são diagnóstico algorítmico; métricas apenas dentro do suporte são a avaliação do subconjunto em que a regra permitiria estimativa.

Calcular a concordância da camada local de severidade apenas para saídas projetadas e dentro do suporte. Linhas fora do suporte contam como indisponíveis, nunca como acertos Low. Comparar com as faixas aplicadas diretamente aos alvos CFD e fornecer numeradores, denominadores, cobertura e resultados por cenário. Não reunir T, visibilidade e CO numa única métrica de erro.

## Limites de interpretação

As séries temporais e posições de uma simulação são correlacionadas. Apresentar cada cenário separadamente e não calcular significância como se milhares de pares fossem incêndios independentes. O teste reservado mede generalização entre condições CFD desta mesma geometria e configuração; não constitui validação experimental, de malha, de túnel real, de alarme ou de segurança humana.

Qualquer mudança após abrir os resultados reservados invalida o caráter de teste independente para a análise modificada. Registrar a nova análise como exploração e não usar os mesmos três casos para uma alegação confirmatória posterior.
