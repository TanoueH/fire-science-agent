"""Describe train/test range shifts using development scenarios only."""
from pathlib import Path
import json
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
DATA = pd.read_csv(ROOT / 'data/development-device-data-long.csv')
PRED = pd.read_csv(ROOT / 'results/development-predictions.csv')
OBSERVED = ['S01', 'S02', 'S09', 'S10']
TARGETS = ['S03', 'S04', 'S05', 'S06', 'S07', 'S08']
FIELDS = ['temperature_C', 'visibility_m', 'CO_ppm']
INPUT_FIELDS = FIELDS + ['U_m_s']
SCENARIOS = ['S1', 'S2', 'S3', 'P05V02', 'P10V03', 'P20V01']
OUT = ROOT / 'audit'


def case_matrices(frame):
    times = np.sort(frame.time_s.unique())
    xy = frame.groupby('sensor_id')[['x_m', 'z_m']].first()
    wide = {field: frame.pivot(index='time_s', columns='sensor_id', values=field).reindex(times)
            for field in INPUT_FIELDS}
    X = np.column_stack([wide[field][site].to_numpy()
                         for field in INPUT_FIELDS for site in OBSERVED])
    locations = xy.loc[TARGETS].to_numpy()
    X = np.column_stack([np.repeat(X, len(TARGETS), axis=0),
                         np.tile(locations, (len(times), 1))])
    Y = np.column_stack([frame.pivot(index='time_s', columns='sensor_id', values=field)
                         .reindex(index=times, columns=TARGETS).to_numpy().reshape(-1)
                         for field in FIELDS])
    return X, Y


feature_names = [field + '@' + site for field in INPUT_FIELDS for site in OBSERVED] + ['target_x_m', 'target_z_m']
range_rows = []
target_rows = []
rf_site_rows = []
for heldout in SCENARIOS:
    train_frames = [DATA[DATA.scenario == scenario] for scenario in SCENARIOS if scenario != heldout]
    train_matrices = [case_matrices(frame) for frame in train_frames]
    X_train = np.concatenate([pair[0] for pair in train_matrices])
    Y_train = np.concatenate([pair[1] for pair in train_matrices])
    test_frame = DATA[DATA.scenario == heldout]
    X_test, Y_test = case_matrices(test_frame)
    outside_by_feature = []
    for j, name in enumerate(feature_names):
        low, high = float(X_train[:, j].min()), float(X_train[:, j].max())
        below = X_test[:, j] < low
        above = X_test[:, j] > high
        fraction = float((below | above).mean())
        outside_by_feature.append(fraction)
        range_rows.append({
            'test_scenario': heldout, 'feature': name,
            'training_min': low, 'training_max': high,
            'test_min': float(X_test[:, j].min()), 'test_max': float(X_test[:, j].max()),
            'fraction_test_rows_outside_training_minmax': fraction,
        })
    any_outside = np.any(np.column_stack([
        (X_test[:, j] < X_train[:, j].min()) | (X_test[:, j] > X_train[:, j].max())
        for j in range(X_train.shape[1])
    ]), axis=1)
    for k, field in enumerate(FIELDS):
        low, high = float(Y_train[:, k].min()), float(Y_train[:, k].max())
        frac = float(((Y_test[:, k] < low) | (Y_test[:, k] > high)).mean())
        target_rows.append({
            'test_scenario': heldout, 'quantity': field,
            'training_target_min': low, 'training_target_max': high,
            'test_target_min': float(Y_test[:, k].min()), 'test_target_max': float(Y_test[:, k].max()),
            'fraction_test_target_values_outside_training_range': frac,
            'fraction_test_rows_with_any_predictor_outside_training_minmax': float(any_outside.mean()),
        })
    rf = PRED[(PRED.scenario == heldout) & (PRED.method == 'random_forest')]
    truth = PRED[(PRED.scenario == heldout) & (PRED.method == 'spatial_linear')]
    for site in TARGETS:
        for field in FIELDS:
            actual = truth.loc[truth.target_site == site, 'reference_' + field].to_numpy()
            estimate = rf.loc[rf.target_site == site, 'estimate_' + field].to_numpy()
            rf_site_rows.append({
                'test_scenario': heldout, 'target_site': site, 'quantity': field,
                'reference_min': float(actual.min()), 'reference_max': float(actual.max()),
                'random_forest_estimate_min': float(estimate.min()),
                'random_forest_estimate_max': float(estimate.max()),
                'MAE': float(np.abs(actual - estimate).mean()),
                'bias': float((estimate - actual).mean()),
            })

range_df = pd.DataFrame(range_rows)
target_df = pd.DataFrame(target_rows)
rf_site_df = pd.DataFrame(rf_site_rows)
range_df.to_csv(OUT / 'predictor-range-diagnostics.csv', index=False)
target_df.to_csv(OUT / 'target-range-diagnostics.csv', index=False)
rf_site_df.to_csv(OUT / 'random-forest-site-diagnostics.csv', index=False)

summary = {
    'scope': 'descriptive train/test min-max comparison using development scenarios only',
    'heldout_cases_accessed': False,
    'all_development_scenarios': SCENARIOS,
    'warning': 'Min-max exceedance is a diagnostic, not yet a calibrated applicability rule or sensor-resolution threshold.',
    'target_range_diagnostics': target_df.to_dict(orient='records'),
    'predictors_with_any_minmax_exceedance': (
        range_df[range_df.fraction_test_rows_outside_training_minmax > 0]
        .groupby('test_scenario').agg(features=('feature', 'count'),
                                     max_feature_exceedance_fraction=('fraction_test_rows_outside_training_minmax', 'max'))
        .reset_index().to_dict(orient='records')
    ),
}
(OUT / 'development-range-diagnostic.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
print(json.dumps(summary, indent=2))
