"""Create a portable six-scenario development dataset from reviewed DEVC outputs."""
from pathlib import Path
import csv
import hashlib
import json
import math
import re
import shutil
import sys

PROJECT = Path(__file__).resolve().parents[2]
ROOT = Path(__file__).resolve().parent
DEPS = PROJECT / 'output/fds-reviewed-2026-11-05/.python-deps'
if DEPS.is_dir():
    sys.path.insert(0, str(DEPS))
import numpy as np
import pandas as pd

FACTORIAL = PROJECT / 'output/fds-factorial-2026-11-05'
OLD_PACKAGE = PROJECT / 'output/eaai-virtual-sensing-2026-11-05'
SOURCE_OLD_DATA = OLD_PACKAGE / 'data/device-data-long.csv'
SOURCE_SELECTION = OLD_PACKAGE / 'data/campaign-selection.json'
SOURCE_NEW = FACTORIAL / 'cenapad-download/development'
INPUT_HASHES = FACTORIAL / 'package/INPUT_SHA256SUMS'
DATA_DIR = ROOT / 'data'
RAW_DIR = DATA_DIR / 'raw-new-cases'
AUDIT_DIR = ROOT / 'audit'
LOCAL_INPUT_HASHES = DATA_DIR / 'source-input-sha256sums.txt'
CASES = {
    'P05V02': {'power_MW': 5, 'inlet_normal_VEL_m_s': -2.0},
    'P10V03': {'power_MW': 10, 'inlet_normal_VEL_m_s': -3.0},
    'P20V01': {'power_MW': 20, 'inlet_normal_VEL_m_s': -1.0},
}
SITES = [f'S{i:02d}' for i in range(1, 11)]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def copy_once(source, destination):
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        if sha(source) != sha(destination):
            raise RuntimeError(f'Portable source already exists with different bytes: {destination}')
    else:
        shutil.copy2(source, destination)


def ensure_local(source, destination):
    if destination.exists():
        if source.exists() and sha(source) != sha(destination):
            raise RuntimeError(f'Local source differs from current project source: {destination}')
    else:
        copy_once(source, destination)


def parse_input_hashes():
    hashes = {}
    for line in LOCAL_INPUT_HASHES.read_text(encoding='utf-8').splitlines():
        match = re.match(r'([0-9a-f]{64})  (.+)$', line)
        if match:
            hashes[match.group(2)] = match.group(1)
    return hashes


def device_coordinates(fds_path):
    content = fds_path.read_text(encoding='utf-8', errors='replace')
    pattern = re.compile(
        r"ID=['\"](?:T|VIS|CO|U)_(S\d{2})['\"]\s*,\s*XYZ=\s*"
        r"([-+0-9.eE]+)\s*,\s*([-+0-9.eE]+)\s*,\s*([-+0-9.eE]+)", re.I
    )
    found = {}
    for site, x, y, z in pattern.findall(content):
        coord = tuple(float(value) for value in (x, y, z))
        if site in found and found[site] != coord:
            raise ValueError(f'Inconsistent coordinates for {site} in {fds_path}')
        found[site] = coord
    if set(found) != set(SITES):
        raise ValueError(f'Expected coordinates for S01-S10 in {fds_path}, got {sorted(found)}')
    return found


def csv_units_and_header(path):
    with path.open('r', encoding='utf-8-sig', newline='') as stream:
        rows = csv.reader(stream)
        units = next(rows)
        header = next(rows)
    if len(units) != len(header):
        raise ValueError(f'Unit/header width mismatch in {path}')
    return dict(zip(header, units))


def main():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    RAW_DIR.mkdir(parents=True, exist_ok=True)
    AUDIT_DIR.mkdir(parents=True, exist_ok=True)

    old_data_path = DATA_DIR / 'source-three-scenarios.csv'
    old_selection_path = DATA_DIR / 'source-campaign-selection.json'
    ensure_local(SOURCE_OLD_DATA, old_data_path)
    ensure_local(SOURCE_SELECTION, old_selection_path)
    ensure_local(INPUT_HASHES, LOCAL_INPUT_HASHES)
    old = pd.read_csv(old_data_path)
    selection = json.loads(old_selection_path.read_text(encoding='utf-8'))
    old_velocity = {case['scenario']: float(case['inlet_normal_VEL_m_s'])
                    for case in selection['cases']}
    old['inlet_normal_VEL_m_s'] = old['scenario'].map(old_velocity)
    if old['inlet_normal_VEL_m_s'].isna().any():
        raise ValueError('Missing inlet velocity metadata in prior scenarios')
    prior_coordinates = old.groupby('sensor_id')[['x_m', 'y_m', 'z_m']].first()

    expected_hashes = parse_input_hashes()
    new_frames = []
    case_reviews = []
    raw_manifest = {}
    for case, settings in CASES.items():
        source_case = SOURCE_NEW / case
        prefix = f'eaai20261105_{case}_yup_600s'
        source_files = {
            'input_fds': source_case / f'{prefix}.fds',
            'devc_csv': source_case / f'{prefix}_devc.csv',
            'hrr_csv': source_case / f'{prefix}_hrr.csv',
            'out': source_case / f'{prefix}.out',
            'console_log': source_case / 'console.log',
        }
        local_case = RAW_DIR / case
        local_files = {}
        for kind, source in source_files.items():
            suffix = {'input_fds': '.fds', 'devc_csv': '_devc.csv', 'hrr_csv': '_hrr.csv',
                      'out': '.out', 'console_log': '.log'}[kind]
            destination = local_case / (case + suffix)
            ensure_local(source, destination)
            local_files[kind] = destination

        fds_path = local_files['input_fds']
        expected_rel = f'cases/development/{case}/{prefix}.fds'
        input_hash = sha(fds_path)
        if input_hash != expected_hashes.get(expected_rel):
            raise ValueError(f'FDS input hash differs from reviewed preparation for {case}')
        fds_text = fds_path.read_text(encoding='utf-8', errors='replace')
        if not re.search(r'TMPA\s*=\s*20(?:\.0+)?', fds_text):
            raise ValueError(f'Unexpected ambient input temperature in {case}')
        if not re.search(r'GVEC\s*=\s*0(?:\.0*)?\s*,\s*-9\.81\s*,\s*0(?:\.0*)?', fds_text):
            raise ValueError(f'Unexpected gravity vector in {case}')
        inlet_id = f"INFLOW_{int(abs(settings['inlet_normal_VEL_m_s']))}MS"
        inlet_match = re.search(rf"ID=['\"]{inlet_id}['\"](.*?)/", fds_text, re.S)
        velocity_match = re.search(r'VEL\s*=\s*([-+0-9.eE]+)', inlet_match.group(1)) if inlet_match else None
        if not velocity_match or not math.isclose(float(velocity_match.group(1)),
                                                   settings['inlet_normal_VEL_m_s'], abs_tol=1e-12):
            raise ValueError(f'Inlet velocity input is inconsistent in {case}')

        coords = device_coordinates(fds_path)
        for site, xyz in coords.items():
            if tuple(prior_coordinates.loc[site, ['x_m', 'y_m', 'z_m']].astype(float)) != xyz:
                raise ValueError(f'Sensor coordinate differs from the previously reviewed layout: {case}/{site}')

        units = csv_units_and_header(local_files['devc_csv'])
        if units.get('Time') != 's':
            raise ValueError(f'Unexpected time unit in {case}')
        for site in SITES:
            expected_units = {f'T_{site}': 'C', f'VIS_{site}': 'm',
                              f'CO_{site}': 'mol/mol', f'U_{site}': 'm/s'}
            for column, unit in expected_units.items():
                if units.get(column) != unit:
                    raise ValueError(f'Unexpected unit for {column} in {case}: {units.get(column)}')

        raw = pd.read_csv(local_files['devc_csv'], skiprows=1)
        required = ['Time'] + [f'{prefix}_{site}' for site in SITES
                               for prefix in ('T', 'VIS', 'CO', 'U')]
        if any(column not in raw for column in required):
            raise ValueError(f'Missing sensor columns in {case}')
        times = raw['Time'].to_numpy(dtype=float)
        if len(times) != 601 or not np.all(np.diff(times) > 0) or times[0] != 0 or times[-1] != 600:
            raise ValueError(f'DEVС output does not span 601 strictly ordered points from 0 to 600 s: {case}')
        if not np.isfinite(raw[required].to_numpy(dtype=float)).all():
            raise ValueError(f'Non-finite device output in {case}')

        hrr = pd.read_csv(local_files['hrr_csv'], skiprows=1)
        hrr_window = hrr.loc[(hrr['Time'] >= 300.0) & (hrr['Time'] <= 600.0), 'HRR']
        mean_hrr_MW = float(hrr_window.mean()) / 1000.0
        if len(hrr) != 121 or float(hrr['Time'].iloc[-1]) != 600.0:
            raise ValueError(f'HRR output does not span the declared 600 s: {case}')
        if abs(mean_hrr_MW - settings['power_MW']) / settings['power_MW'] > 0.05:
            raise ValueError(f'Achieved HRR is outside 5% of nominal power in {case}')

        log_text = local_files['console_log'].read_text(encoding='utf-8', errors='replace')
        out_text = local_files['out'].read_text(encoding='utf-8', errors='replace')
        if 'STOP: FDS completed successfully' not in log_text or '600.00 s' not in log_text:
            raise ValueError(f'FDS completion or 600 s is not recorded in {case}')
        if 'FDS-6.8.0' not in out_text or 'Ambient Temperature (C)' not in out_text or '20.00' not in out_text:
            raise ValueError(f'FDS revision or ambient temperature is unexpected in {case}')

        rows = []
        for site in SITES:
            x, y, z = coords[site]
            for i, time_s in enumerate(times):
                rows.append({
                    'scenario': case,
                    'CHID': prefix,
                    'sensor_id': site,
                    'time_s': time_s,
                    'x_m': x, 'y_m': y, 'z_m': z,
                    'temperature_C': float(raw[f'T_{site}'].iloc[i]),
                    'visibility_m': float(raw[f'VIS_{site}'].iloc[i]),
                    'CO_ppm': float(raw[f'CO_{site}'].iloc[i]) * 1_000_000.0,
                    'U_m_s': float(raw[f'U_{site}'].iloc[i]),
                    'declared_HRR_MW': settings['power_MW'],
                    'configured_HRR_MW': mean_hrr_MW,
                    'inlet_normal_VEL_m_s': settings['inlet_normal_VEL_m_s'],
                })
        new_frames.append(pd.DataFrame(rows))
        raw_manifest[case] = {kind: {'relative_path': str(path.relative_to(ROOT)), 'sha256': sha(path),
                                      'bytes': path.stat().st_size}
                              for kind, path in local_files.items()}
        case_reviews.append({
            'case': case, 'input_hash_matches_preparation': True,
            'FDS_revision': 'FDS-6.8.0', 'ambient_C': 20.0,
            'gravity_vector': [0.0, -9.81, 0.0],
            'input_inlet_normal_velocity_m_s': settings['inlet_normal_VEL_m_s'],
            'DEVC_rows': len(raw), 'DEVC_start_s': float(times[0]), 'DEVC_end_s': float(times[-1]),
            'DEVC_columns': len(raw.columns), 'DEVC_all_finite': True,
            'HRR_rows': len(hrr), 'HRR_end_s': float(hrr['Time'].iloc[-1]),
            'mean_HRR_300_600_MW': mean_hrr_MW,
            'relative_HRR_difference_percent': 100.0 * (mean_hrr_MW - settings['power_MW']) / settings['power_MW'],
            'console_success_and_600_s': True,
        })

    combined = pd.concat([old, *new_frames], ignore_index=True)
    if combined.isna().any().any() or not np.isfinite(combined.select_dtypes(include=[np.number]).to_numpy()).all():
        raise ValueError('Combined data contain missing or non-finite values')
    expected_scenarios = {'S1', 'S2', 'S3', *CASES.keys()}
    if set(combined['scenario']) != expected_scenarios or len(combined) != 6 * 10 * 601:
        raise ValueError('Unexpected scenario roster or dataset length')
    if combined.duplicated(['scenario', 'sensor_id', 'time_s']).any():
        raise ValueError('Duplicate scenario/site/time rows found')
    if not combined.groupby(['scenario', 'sensor_id']).size().eq(601).all():
        raise ValueError('Every scenario and sensor must have exactly 601 records')
    if (combined['CO_ppm'] < 0).any() or (combined['visibility_m'] < 0).any():
        raise ValueError('Negative CO or visibility found')

    output = DATA_DIR / 'development-device-data-long.csv'
    combined.to_csv(output, index=False, float_format='%.12g')
    source_manifest = {
        'prior_three_scenario_dataset': {'path': str(old_data_path.relative_to(ROOT)), 'sha256': sha(old_data_path),
                                         'rows': int(len(old))},
        'new_raw_case_files': raw_manifest,
        'new_input_hashes_match_preparation_manifest': True,
        'remote_output_hash_inventory_available_for_bytewise_comparison': False,
        'note': 'Local output files and solver logs were inspected; complete remote output SHA-256 receipts were not supplied, so transfer identity for output bytes is not independently established.',
        'CO_conversion': 'FDS volume fraction (mol/mol) multiplied by 1,000,000 to ppm',
        'combined_dataset': {'path': str(output.relative_to(ROOT)), 'sha256': sha(output),
                             'rows': int(len(combined)), 'scenarios': sorted(expected_scenarios),
                             'sites_per_scenario': 10, 'samples_per_site': 601},
        'holdout_case_files_accessed': False,
    }
    (AUDIT_DIR / 'source-manifest.json').write_text(json.dumps(source_manifest, indent=2) + '\n', encoding='utf-8')
    review = {
        'new_development_cases': case_reviews,
        'combined_rows': int(len(combined)),
        'combined_case_site_groups': int(combined.groupby(['scenario', 'sensor_id']).ngroups),
        'all_groups_have_601_rows': True,
        'sensor_layout_matches_prior_data': True,
        'all_device_values_finite': True,
        'visibility_and_CO_nonnegative': True,
        'reserved_holdout_output_histories_examined': False,
        'physical_validation_complete': False,
    }
    (AUDIT_DIR / 'development-data-qc.json').write_text(json.dumps(review, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(review, indent=2))


if __name__ == '__main__':
    main()
