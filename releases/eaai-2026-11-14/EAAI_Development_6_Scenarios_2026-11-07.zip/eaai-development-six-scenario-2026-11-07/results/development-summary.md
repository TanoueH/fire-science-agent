# Resultados de desenvolvimento — seis cenários

Validação cruzada por cenário completo; cada linha temporal e alvo é correlacionado dentro da simulação. Os casos reservados P05V03, P10V01 e P20V02 não foram abertos.

## MAE médio entre cenários (cada cenário recebe o mesmo peso)

| Método | Grandeza | MAE médio | RMSE médio | Pior MAE de cenário | Fração média projetada |
|---|---:|---:|---:|---:|---:|
| nearest | CO_ppm | 3.2116 ppm | 5.9 ppm | 7.08089 ppm | 0.0000% |
| random_forest | CO_ppm | 9.62115 ppm | 11.4179 ppm | 35.8463 ppm | 0.0000% |
| ridge | CO_ppm | 4.77932 ppm | 6.07734 ppm | 9.77477 ppm | 20.7709% |
| spatial_linear | CO_ppm | 3.67342 ppm | 4.99007 ppm | 7.89241 ppm | 0.0000% |
| nearest | temperature_C | 9.85811 C | 16.8444 C | 20.1341 C | 0.0000% |
| random_forest | temperature_C | 30.0707 C | 35.5391 C | 109.919 C | 0.0000% |
| ridge | temperature_C | 15.224 C | 18.9794 C | 29.8628 C | 0.0000% |
| spatial_linear | temperature_C | 9.85251 C | 13.0709 C | 17.2042 C | 0.0000% |
| nearest | visibility_m | 2.96701 m | 6.72664 m | 6.95911 m | 0.0000% |
| random_forest | visibility_m | 4.73188 m | 6.6686 m | 14.2447 m | 0.0000% |
| ridge | visibility_m | 6.80818 m | 8.1682 m | 14.0875 m | 34.5027% |
| spatial_linear | visibility_m | 3.88995 m | 5.42089 m | 8.52409 m | 0.0000% |

## Rodadas em que o método teve MAE menor que interpolação linear

| Método | Grandeza | Rodadas de 6 |
|---|---|---:|
| nearest | CO_ppm | 4/6 |
| nearest | temperature_C | 3/6 |
| nearest | visibility_m | 4/6 |
| random_forest | CO_ppm | 2/6 |
| random_forest | temperature_C | 2/6 |
| random_forest | visibility_m | 2/6 |
| ridge | CO_ppm | 2/6 |
| ridge | temperature_C | 0/6 |
| ridge | visibility_m | 2/6 |

Estas métricas são exploração em simulações CFD, não validação em escala real. Não foram calculados intervalos de confiança ou testes de significância tratando amostras temporais como incêndios independentes. Não usar estes resultados para afirmar superioridade geral de ML nem desempenho de segurança.
