# Avaliação final dos três cenários reservados

Protocolo congelado em `PREHOLDOUT_PROTOCOL.md`; não houve ajuste de hiperparâmetros nem escolha de método após abrir os resultados. As métricas completas incluem diagnóstico de extrapolação; a faixa local estimada só é calculada quando as 18 entradas estão dentro do suporte min–max do treino. Fora dele, a classe estimada fica indisponível.

## MAE após projeção de limites, em todos os pares (inclui extrapolação)

| Método | Grandeza | Média por cenário | Pior cenário | Fração média projetada |
|---|---|---:|---:|---:|
| nearest | CO_ppm | 2.687 ppm | 4.4876 ppm | 0.000% |
| random_forest | CO_ppm | 3.54479 ppm | 5.69957 ppm | 0.000% |
| ridge | CO_ppm | 2.04968 ppm | 3.58531 ppm | 24.977% |
| spatial_linear | CO_ppm | 2.34759 ppm | 3.55333 ppm | 0.000% |
| nearest | temperature_C | 7.58612 °C | 12.7551 °C | 0.000% |
| random_forest | temperature_C | 9.34544 °C | 15.245 °C | 0.000% |
| ridge | temperature_C | 7.79989 °C | 10.2422 °C | 0.000% |
| spatial_linear | temperature_C | 5.48847 °C | 9.18145 °C | 0.000% |
| nearest | visibility_m | 0.645394 m | 1.21327 m | 0.000% |
| random_forest | visibility_m | 0.369207 m | 0.658967 m | 0.000% |
| ridge | visibility_m | 1.96454 m | 3.25239 m | 37.983% |
| spatial_linear | visibility_m | 0.650128 m | 1.28764 m | 0.000% |

## Cobertura por cenário

| Cenário | Pares disponíveis / 3606 | Cobertura |
|---|---:|---:|
| P05V03 | 3600 / 3606 | 99.83% |
| P10V01 | 3606 / 3606 | 100.00% |
| P20V02 | 3606 / 3606 | 100.00% |

## Severidade local nas previsões disponíveis

Os números abaixo são comparações com faixas de pesquisa aplicadas aos resultados CFD; não são desempenho de alarme ou risco humano.

| Cenário | Método | Cobertura | Concordância | Subestimação |
|---|---|---:|---:|---:|
| P05V03 | nearest | 99.83% | 100.00% | 0.00% |
| P05V03 | spatial_linear | 99.83% | 100.00% | 0.00% |
| P05V03 | ridge | 99.83% | 99.94% | 0.00% |
| P05V03 | random_forest | 99.83% | 100.00% | 0.00% |
| P10V01 | nearest | 100.00% | 96.31% | 2.38% |
| P10V01 | spatial_linear | 100.00% | 96.73% | 2.44% |
| P10V01 | ridge | 100.00% | 68.16% | 31.72% |
| P10V01 | random_forest | 100.00% | 98.64% | 0.83% |
| P20V02 | nearest | 100.00% | 95.48% | 3.16% |
| P20V02 | spatial_linear | 100.00% | 91.15% | 5.41% |
| P20V02 | ridge | 100.00% | 58.18% | 39.10% |
| P20V02 | random_forest | 100.00% | 95.59% | 2.80% |

Cada caso permanece uma simulação CFD; os pontos temporais e espaciais não são réplicas independentes. Esta avaliação não demonstra validade experimental, em outra malha/geometria, nem para segurança humana ou operação real.
