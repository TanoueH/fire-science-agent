# Candidato a regra de abstinência: faixa min–max

Regra exploratória aplicada a todos os métodos por igual: para um instante, emitir estimativa somente se as 18 entradas (16 leituras observadas + x,z do alvo) estiverem dentro dos mínimos e máximos do treino. Caso contrário, marcar `estimativa indisponível`. Esta regra não foi calibrada para resolução de sensores, não verifica combinações conjuntas de entradas e ainda não é uma regra operacional validada.

| Cenário avaliado | Linhas aplicáveis / 3606 | Cobertura |
|---|---:|---:|
| S1 | 3600 / 3606 | 99.83% |
| S2 | 3606 / 3606 | 100.00% |
| S3 | 3558 / 3606 | 98.67% |
| P05V02 | 3606 / 3606 | 100.00% |
| P10V03 | 3588 / 3606 | 99.50% |
| P20V01 | 294 / 3606 | 8.15% |

## Erros dentro da faixa do treino

Cada métrica abaixo usa apenas os instantes onde a regra emitiria estimativa. Unidades continuam separadas.

| Cenário | Método | MAE T (°C) | MAE vis. (m) | MAE CO (ppm) | Concordância de faixa | Subestimação |
|---|---|---:|---:|---:|---:|---:|
| S1 | nearest | 5.0889 | 0.90798 | 1.7537 | 0.90944 | 0.058333 |
| S1 | random_forest | 16.357 | 2.803 | 5.1595 | 0.61083 | 0.37583 |
| S1 | ridge | 6.213 | 10.462 | 2.2326 | 0.064722 | 0.92056 |
| S1 | spatial_linear | 4.0938 | 0.79153 | 1.5323 | 0.91833 | 0.043333 |
| S2 | nearest | 17.652 | 6.9591 | 5.6371 | 0.72379 | 0.25402 |
| S2 | random_forest | 31.102 | 14.245 | 10.529 | 0.45008 | 0.54992 |
| S2 | ridge | 29.863 | 14.088 | 9.7748 | 0.45008 | 0.54992 |
| S2 | spatial_linear | 17.204 | 7.9775 | 5.417 | 0.37632 | 0.53633 |
| S3 | nearest | 8.0868 | 3.4135 | 2.2687 | 0.84148 | 0 |
| S3 | random_forest | 21.4 | 7.8154 | 5.7082 | 0.5118 | 0 |
| S3 | ridge | 14.231 | 5.6897 | 4.398 | 0.67735 | 0 |
| S3 | spatial_linear | 11.457 | 5.1203 | 3.4031 | 0.75548 | 0 |
| P05V02 | nearest | 7.1388 | 5.6827 | 2.4181 | 0.72573 | 0 |
| P05V02 | random_forest | 1.5106 | 1.1005 | 0.48187 | 0.99861 | 0 |
| P05V02 | ridge | 14.623 | 8.3381 | 4.8579 | 0.63894 | 0 |
| P05V02 | spatial_linear | 10.393 | 8.5241 | 3.6272 | 0.58541 | 0 |
| P10V03 | nearest | 1.0156 | 0.20325 | 0.099468 | 0.99192 | 0 |
| P10V03 | random_forest | 0.15686 | 0.0024481 | 0.0010607 | 1 | 0 |
| P10V03 | ridge | 10.217 | 0.023824 | 0.027739 | 0.99944 | 0 |
| P10V03 | spatial_linear | 1.0919 | 0.30487 | 0.1492 | 0.99247 | 0 |
| P20V01 | nearest | 11.294 | 5.4846 | 3.9246 | 0.69048 | 0.2483 |
| P20V01 | random_forest | 8.0721 | 2.3353 | 2.7934 | 0.69728 | 0.29252 |
| P20V01 | ridge | 13.432 | 7.6374 | 4.4484 | 0.55782 | 0.41837 |
| P20V01 | spatial_linear | 6.8297 | 5.1787 | 2.511 | 0.57143 | 0.37075 |

Este resultado demonstra apenas a relação entre faixa de entradas e cobertura/erro nestes seis cenários CFD. O critério não pode ser chamado de sensor digital validado, classificação de risco confiável ou garantia de segurança. A regra deve permanecer em desenvolvimento até ser congelada antes de qualquer abertura do conjunto reservado.
