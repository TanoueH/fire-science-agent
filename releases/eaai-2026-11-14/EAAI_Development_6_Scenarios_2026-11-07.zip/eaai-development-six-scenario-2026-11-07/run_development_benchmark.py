"""Development-only LOSO benchmark on six complete, reviewed CFD scenarios."""
from pathlib import Path
import hashlib
import json
import os
import platform
import sys
import time
import warnings

ROOT = Path(__file__).resolve().parent
PROJECT = Path(__file__).resolve().parents[2]
DEPS = PROJECT / 'output/fds-reviewed-2026-11-05/.python-deps'
if DEPS.is_dir():
    sys.path.insert(0, str(DEPS))
os.environ['OMP_NUM_THREADS'] = '1'
import numpy as np
import pandas as pd
import scipy
import sklearn
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import Ridge
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

from severity import evaluate, project_predictions, VERSION, LABELS

DATA_PATH = ROOT / 'data/development-device-data-long.csv'
OUT = ROOT / 'results'
AUDIT = ROOT / 'audit'
OUT.mkdir(parents=True, exist_ok=True)
AUDIT.mkdir(parents=True, exist_ok=True)

OBSERVED = ['S01', 'S02', 'S09', 'S10']
TARGETS = ['S03', 'S04', 'S05', 'S06', 'S07', 'S08']
SCENARIOS = ['S1', 'S2', 'S3', 'P05V02', 'P10V03', 'P20V01']
FIELDS = ['temperature_C', 'visibility_m', 'CO_ppm']
INPUT_FIELDS = FIELDS + ['U_m_s']
UNITS = {'temperature_C': 'C', 'visibility_m': 'm', 'CO_ppm': 'ppm'}
RF_PARAMS = {'n_estimators': 100, 'max_depth': 10, 'min_samples_leaf': 5,
             'random_state': 42, 'n_jobs': 1}
METHODS = ['nearest', 'spatial_linear', 'ridge', 'random_forest']


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


data = pd.read_csv(DATA_PATH)
assert len(data) == 6 * 10 * 601
assert set(data['scenario']) == set(SCENARIOS)
assert not data.duplicated(['scenario', 'sensor_id', 'time_s']).any()
assert data.groupby(['scenario', 'sensor_id']).size().eq(601).all()
assert set(OBSERVED).isdisjoint(TARGETS)
assert set(OBSERVED + TARGETS) == set(data['sensor_id'].unique())
assert np.isfinite(data[INPUT_FIELDS + ['time_s', 'x_m', 'y_m', 'z_m']].to_numpy()).all()
assert data.groupby(['scenario', 'sensor_id'])[['x_m', 'y_m', 'z_m']].nunique().eq(1).all().all()

protocol = ROOT / 'PROTOCOL_DEV.md'
lock = {
    'stage': 'development_only_six_scenario_LOSO',
    'protocol_sha256': sha(protocol),
    'data_sha256': sha(DATA_PATH),
    'scenarios': SCENARIOS,
    'observed_sites': OBSERVED,
    'target_sites': TARGETS,
    'input_fields': INPUT_FIELDS,
    'output_fields': FIELDS,
    'split': 'leave one complete development scenario out; train on the other five',
    'ridge_alpha': 1.0,
    'random_forest': RF_PARAMS,
    'prediction_projection': {'temperature_lower_C': -273.15,
                              'visibility_m': [0.0, 30.0], 'CO_ppm': [0.0, 1e6]},
    'severity_version': VERSION,
    'reserved_cases_excluded': ['P05V03', 'P10V01', 'P20V02'],
}
lock_path = AUDIT / 'protocol-lock.json'
if lock_path.exists():
    if json.loads(lock_path.read_text(encoding='utf-8')) != lock:
        raise RuntimeError('Development protocol or data changed; create a new version instead of overwriting.')
else:
    lock_path.write_text(json.dumps(lock, indent=2) + '\n', encoding='utf-8')


def make_case(scenario):
    frame = data[data.scenario == scenario]
    times = np.sort(frame.time_s.unique())
    if len(times) != 601 or times[0] != 0 or times[-1] != 600:
        raise ValueError(f'Unexpected output timeline for {scenario}')
    coordinates = frame.groupby('sensor_id')[['x_m', 'y_m', 'z_m']].first()
    wide = {field: frame.pivot(index='time_s', columns='sensor_id', values=field).reindex(index=times)
            for field in INPUT_FIELDS}
    if any(table.isna().any().any() for table in wide.values()):
        raise ValueError(f'Missing predictors in {scenario}')
    observed = np.column_stack([wide[field][site].to_numpy()
                                for field in INPUT_FIELDS for site in OBSERVED])
    locations = coordinates.loc[TARGETS, ['x_m', 'z_m']].to_numpy()
    X = np.column_stack([np.repeat(observed, len(TARGETS), axis=0),
                         np.tile(locations, (len(times), 1))])
    Y = np.column_stack([wide[field][TARGETS].to_numpy().reshape(-1) for field in FIELDS])
    nearest = np.zeros_like(Y)
    spatial_linear = np.zeros_like(Y)
    for j, site in enumerate(TARGETS):
        x, _, z = coordinates.loc[site]
        anchors = coordinates.loc[OBSERVED]
        anchors = anchors[anchors.z_m == z].sort_values('x_m')
        if len(anchors) != 2:
            raise ValueError(f'Expected two observed anchors on target side for {site}')
        left, right = anchors.index
        x0, x1 = float(anchors.iloc[0].x_m), float(anchors.iloc[1].x_m)
        fraction = (x - x0) / (x1 - x0)
        closest = left if (x - x0) <= (x1 - x) else right
        for k, field in enumerate(FIELDS):
            nearest[j::len(TARGETS), k] = wide[field][closest].to_numpy()
            spatial_linear[j::len(TARGETS), k] = (
                (1 - fraction) * wide[field][left].to_numpy()
                + fraction * wide[field][right].to_numpy()
            )
    meta = pd.DataFrame({
        'scenario': scenario,
        'time_s': np.repeat(times, len(TARGETS)),
        'target_site': np.tile(TARGETS, len(times)),
        'x_m': np.tile(locations[:, 0], len(times)),
        'z_m': np.tile(locations[:, 1], len(times)),
    })
    if X.shape != (3606, 18) or Y.shape != (3606, 3):
        raise ValueError(f'Unexpected predictor/target dimensions for {scenario}')
    return {'X': X, 'Y': Y, 'meta': meta,
            'nearest': nearest, 'spatial_linear': spatial_linear}


CASES = {scenario: make_case(scenario) for scenario in SCENARIOS}
FEATURES = [field + '@' + site for field in INPUT_FIELDS for site in OBSERVED] + ['target_x_m', 'target_z_m']
assert len(FEATURES) == 18
metrics, site_metrics, severity_metrics, predictions = [], [], [], []
fit_log, warning_rows, scale_rows = [], [], []
start = time.perf_counter()


def errors(truth, pred):
    err = pred - truth
    denominator = float(np.sum((truth - truth.mean()) ** 2))
    return {
        'MAE': float(np.abs(err).mean()),
        'RMSE': float(np.sqrt((err ** 2).mean())),
        'max_absolute_error': float(np.abs(err).max()),
        'bias': float(err.mean()),
        'R2': float(1 - np.sum(err ** 2) / denominator) if denominator > 1e-12 else None,
    }


for heldout in SCENARIOS:
    train_scenarios = [scenario for scenario in SCENARIOS if scenario != heldout]
    X_train = np.concatenate([CASES[scenario]['X'] for scenario in train_scenarios])
    Y_train = np.concatenate([CASES[scenario]['Y'] for scenario in train_scenarios])
    test = CASES[heldout]
    X_test, Y_test = test['X'], test['Y']
    if len(X_train) != 5 * 3606 or len(X_test) != 3606:
        raise ValueError('Scenario holdout split is not complete')

    scaler = StandardScaler().fit(X_train)
    for name, mean, scale, variance in zip(FEATURES, scaler.mean_, scaler.scale_, scaler.var_):
        scale_rows.append({'heldout_scenario': heldout, 'feature': name,
                           'training_mean': float(mean), 'standard_scaler_scale': float(scale),
                           'training_variance': float(variance),
                           'training_unique_values': int(np.unique(X_train[:, FEATURES.index(name)]).size)})

    true_severity = evaluate(Y_test)
    for method in METHODS:
        fit_start = time.perf_counter()
        if method in ('nearest', 'spatial_linear'):
            raw = test[method].copy()
        else:
            estimates = []
            for k, field in enumerate(FIELDS):
                if method == 'ridge':
                    model = make_pipeline(StandardScaler(), Ridge(alpha=1.0))
                else:
                    model = RandomForestRegressor(**RF_PARAMS)
                with warnings.catch_warnings(record=True) as caught:
                    warnings.simplefilter('always')
                    model.fit(X_train, Y_train[:, k])
                    estimates.append(model.predict(X_test))
                warning_rows.extend({
                    'heldout_scenario': heldout, 'method': method, 'quantity': field,
                    'category': item.category.__name__, 'message': str(item.message)
                } for item in caught)
            raw = np.column_stack(estimates)

        estimate, projected = project_predictions(raw)
        true_severity = evaluate(Y_test)
        estimated_severity = evaluate(estimate)
        fit_log.append({'heldout_scenario': heldout, 'method': method,
                        'training_scenarios': train_scenarios,
                        'training_rows': int(len(X_train)), 'test_rows': int(len(X_test)),
                        'fit_predict_seconds': float(time.perf_counter() - fit_start)})
        for k, field in enumerate(FIELDS):
            metrics.append({
                'test_scenario': heldout, 'method': method, 'quantity': field,
                'unit': UNITS[field], 'n_temporal_spatial_rows': int(len(Y_test)),
                'projected_fraction': float(projected[:, k].mean()),
                **errors(Y_test[:, k], estimate[:, k]),
            })
            for site in TARGETS:
                mask = test['meta'].target_site.to_numpy() == site
                site_metrics.append({
                    'test_scenario': heldout, 'target_site': site, 'method': method,
                    'quantity': field, 'unit': UNITS[field],
                    **errors(Y_test[mask, k], estimate[mask, k]),
                })

        actual_band = true_severity['band']
        estimated_band = estimated_severity['band']
        elevated, critical = actual_band > 0, actual_band == 3
        severity_metrics.append({
            'test_scenario': heldout, 'method': method, 'n_temporal_spatial_rows': int(len(Y_test)),
            'band_agreement': float((actual_band == estimated_band).mean()),
            'underestimated_band_fraction': float((estimated_band < actual_band).mean()),
            'overestimated_band_fraction': float((estimated_band > actual_band).mean()),
            'estimated_low_given_elevated_reference_fraction': (
                float((estimated_band[elevated] == 0).mean()) if elevated.any() else None),
            'missed_critical_reference_fraction': (
                float((estimated_band[critical] < 3).mean()) if critical.any() else None),
            'gradual_indicator_MAE': float(np.abs(true_severity['indicator'] - estimated_severity['indicator']).mean()),
            **{'reference_' + LABELS[i]: int((actual_band == i).sum()) for i in range(4)},
            **{'estimated_' + LABELS[i]: int((estimated_band == i).sum()) for i in range(4)},
        })

        frame = test['meta'].copy()
        frame['method'] = method
        for k, field in enumerate(FIELDS):
            frame['reference_' + field] = Y_test[:, k]
            frame['estimate_' + field] = estimate[:, k]
        frame['reference_local_band'] = actual_band
        frame['estimated_local_band'] = estimated_band
        frame['reference_gradual_indicator'] = true_severity['indicator']
        frame['estimated_gradual_indicator'] = estimated_severity['indicator']
        predictions.append(frame)

        print(json.dumps({
            'test_scenario': heldout, 'method': method,
            'MAE': {field: round(metrics[-len(FIELDS) + k]['MAE'], 6) for k, field in enumerate(FIELDS)},
            'seconds': round(fit_log[-1]['fit_predict_seconds'], 2),
        }), flush=True)


metric_df = pd.DataFrame(metrics)
site_df = pd.DataFrame(site_metrics)
severity_df = pd.DataFrame(severity_metrics)
prediction_df = pd.concat(predictions, ignore_index=True)
metric_df.to_csv(OUT / 'metrics-by-scenario.csv', index=False)
site_df.to_csv(OUT / 'metrics-by-target-site.csv', index=False)
severity_df.to_csv(OUT / 'severity-screening-by-scenario.csv', index=False)
prediction_df.to_csv(OUT / 'development-predictions.csv', index=False)
pd.DataFrame(scale_rows).to_csv(AUDIT / 'training-feature-scales.csv', index=False)
pd.DataFrame(warning_rows, columns=['heldout_scenario', 'method', 'quantity', 'category', 'message']).to_csv(
    AUDIT / 'model-warnings.csv', index=False)
summary = metric_df.groupby(['method', 'quantity'], as_index=False).agg(
    mean_scenario_MAE=('MAE', 'mean'), mean_scenario_RMSE=('RMSE', 'mean'),
    worst_scenario_MAE=('MAE', 'max'), mean_projection_fraction=('projected_fraction', 'mean'))
baseline = metric_df[metric_df.method == 'spatial_linear'][['test_scenario', 'quantity', 'MAE']].rename(
    columns={'MAE': 'spatial_linear_MAE'})
comparison = metric_df.merge(baseline, on=['test_scenario', 'quantity'], validate='many_to_one')
comparison['MAE_difference_vs_spatial_linear'] = comparison.MAE - comparison.spatial_linear_MAE
comparison['beats_spatial_linear'] = comparison.MAE < comparison.spatial_linear_MAE
comparison.to_csv(OUT / 'comparison-with-spatial-linear.csv', index=False)
summary.to_csv(OUT / 'development-summary.csv', index=False)

record = {
    'stage': 'development_only_six_scenario_LOSO',
    'protocol_lock': lock,
    'benchmark_script_sha256': sha(Path(__file__)),
    'severity_script_sha256': sha(ROOT / 'severity.py'),
    'environment': {'python': platform.python_version(), 'numpy': np.__version__,
                    'pandas': pd.__version__, 'scipy': scipy.__version__,
                    'scikit_learn': sklearn.__version__},
    'fold_count': len(SCENARIOS), 'scenario_holdout_complete': True,
    'training_rows_per_fold': 5 * 3606, 'test_rows_per_fold': 3606,
    'model_fits': {'ridge': 18, 'random_forest': 18},
    'all_methods_and_scenarios_reported': True,
    'warnings': warning_rows, 'fitting_log': fit_log,
    'holdout_cases_accessed': False,
    'independent_physical_validation_complete': False,
    'status': 'development results only; changes after inspection remain exploratory',
    'elapsed_seconds': time.perf_counter() - start,
}
(AUDIT / 'development-benchmark-record.json').write_text(
    json.dumps(record, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')

counts = comparison[comparison.method.isin(['ridge', 'random_forest', 'nearest'])].groupby(
    ['method', 'quantity'], as_index=False)['beats_spatial_linear'].sum()
lines = [
    '# Resultados de desenvolvimento — seis cenários', '',
    'Validação cruzada por cenário completo; cada linha temporal e alvo é correlacionado dentro da simulação. '
    'Os casos reservados P05V03, P10V01 e P20V02 não foram abertos.', '',
    '## MAE médio entre cenários (cada cenário recebe o mesmo peso)', '',
    '| Método | Grandeza | MAE médio | RMSE médio | Pior MAE de cenário | Fração média projetada |',
    '|---|---:|---:|---:|---:|---:|',
]
for row in summary.sort_values(['quantity', 'method']).to_dict(orient='records'):
    lines.append(f"| {row['method']} | {row['quantity']} | {row['mean_scenario_MAE']:.6g} {UNITS[row['quantity']]} | "
                 f"{row['mean_scenario_RMSE']:.6g} {UNITS[row['quantity']]} | "
                 f"{row['worst_scenario_MAE']:.6g} {UNITS[row['quantity']]} | "
                 f"{row['mean_projection_fraction']:.4%} |")
lines += ['', '## Rodadas em que o método teve MAE menor que interpolação linear', '',
          '| Método | Grandeza | Rodadas de 6 |', '|---|---|---:|']
for row in counts.to_dict(orient='records'):
    lines.append(f"| {row['method']} | {row['quantity']} | {int(row['beats_spatial_linear'])}/6 |")
lines += ['', 'Estas métricas são exploração em simulações CFD, não validação em escala real. '
          'Não foram calculados intervalos de confiança ou testes de significância tratando amostras temporais como incêndios independentes. '
          'Não usar estes resultados para afirmar superioridade geral de ML nem desempenho de segurança.', '']
(OUT / 'development-summary.md').write_text('\n'.join(lines), encoding='utf-8')

print(json.dumps({
    'completed': True, 'status': record['status'],
    'metrics_rows': len(metric_df), 'site_metric_rows': len(site_df),
    'severity_rows': len(severity_df), 'prediction_rows': len(prediction_df),
    'better_than_spatial_linear_counts': counts.to_dict(orient='records'),
    'warnings': len(warning_rows), 'results_dir': str(OUT),
}, indent=2, ensure_ascii=False))
