# Etapa de desenvolvimento EAAI — seis cenários

Esta pasta reúne a auditoria do FDS, a validação por cenário e a avaliação única dos três casos reservados P05V03, P10V01 e P20V02, feita após o congelamento do protocolo.

## Arquivos principais

- `DEVELOPMENT_REPORT.md`: resultados, limites e recomendação metodológica.
- `PROTOCOL_DEV.md`: protocolo de desenvolvimento e casos incluídos/excluídos.
- `PREHOLDOUT_PROTOCOL.md`: especificação congelada para a avaliação final dos três cenários reservados.
- `FINAL_HOLDOUT_REVIEW.md`: leitura científica dos resultados reservados, incluindo métricas brutas/projetadas e limitações.
- `build_reserved_dataset.py`: audita e prepara os três casos reservados; recusa executar após existir registro final.
- `run_reserved_benchmark.py`: faz a única avaliação reservada com o protocolo congelado; recusa uma segunda execução.
- `build_development_dataset.py`: confere proveniência, entradas, ambiente, sensores, HRR e cria o dataset longo.
- `run_development_benchmark.py`: executa o benchmark com separação por cenário completo.
- `diagnose_development.py`: compara faixas de entrada e alvo entre treino e cenário testado.
- `evaluate_support_screen.py`: mede cobertura e erros de um candidato exploratório de abstinência.
- `severity.py`: implementação local versionada das faixas de pesquisa usadas na etapa anterior.
- `data/development-device-data-long.csv`: tabela consolidada de 6 cenários × 10 locais × 601 instantes.
- `data/raw-new-cases/`: cópia portable dos `.fds`, DEVC, HRR, `.out` e logs dos três novos casos.
- `results/`: métricas por cenário e posição, predições de desenvolvimento e reservadas, e diagnósticos de disponibilidade.
- `audit/`: hashes, parâmetros congelados, versões de ambiente e revisões de consistência.

## Reprodução local

Com Python 3.11.9 e as dependências de `requirements-lock.txt`, executar nesta ordem na raiz desta pasta:

```text
python build_development_dataset.py
python run_development_benchmark.py
python diagnose_development.py
python evaluate_support_screen.py
```

Os quatro comandos acima reproduzem apenas a etapa de desenvolvimento. As saídas reservadas já foram avaliadas uma vez. Não reexecute `run_reserved_benchmark.py`: o registro `audit/final-holdout-record.json` bloqueia uma segunda rodada para preservar o conjunto final.

A pasta inclui o CSV dos três cenários anteriores, a seleção usada para eles, o manifesto de hashes preparado, os arquivos brutos dos seis cenários adicionais e a tabela reservada derivada. O dataset de treino contém somente os seis casos de desenvolvimento.

## Limite importante

Os resultados não validam o método para segurança humana ou operação de túnel, não constituem validação física ou de outra geometria e não sustentam superioridade geral de ML. Os casos reservados já foram consultados sob o protocolo congelado; qualquer mudança futura baseada neles deve ser identificada como exploratória.
