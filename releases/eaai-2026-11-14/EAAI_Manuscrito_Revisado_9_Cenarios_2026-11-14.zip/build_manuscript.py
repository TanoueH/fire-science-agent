"""Build the single author-review PDF; keep compiler output in audit."""
from pathlib import Path
import json, shutil, subprocess
ROOT=Path(__file__).resolve().parent
M=ROOT/'manuscript'
pdflatex=shutil.which('pdflatex') or r'C:\Program Files\MiKTeX\miktex\bin\x64\pdflatex.exe'
bibtex=shutil.which('bibtex') or r'C:\Program Files\MiKTeX\miktex\bin\x64\bibtex.exe'
common=['-disable-installer','-no-shell-escape','-interaction=nonstopmode','-halt-on-error','main.tex']
steps=[('pass1',[pdflatex,*common]),('bibtex',[bibtex,'main']),('pass2',[pdflatex,*common]),('pass3',[pdflatex,*common])]
results=[]
for name,cmd in steps:
    run=subprocess.run(cmd,cwd=M,capture_output=True)
    output=(run.stdout+run.stderr).decode('utf-8',errors='replace')
    (ROOT/'audit'/('build-'+name+'.txt')).write_text(output,encoding='utf-8')
    results.append({'step':name,'exit_code':run.returncode})
    print(json.dumps(results[-1]),flush=True)
    if run.returncode:
        print(output[-6000:]); break
(ROOT/'audit/build-status.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
if any(r['exit_code'] for r in results): raise SystemExit(1)
log=(M/'main.log').read_text(encoding='utf-8',errors='replace')
bad=['There were undefined references','There were undefined citations','Overfull \\hbox','Overfull \\vbox']
if any(t in log for t in bad):
    print('\n'.join(line for line in log.splitlines() if any(t in line for t in bad)))
    raise SystemExit('Review and correct unresolved layout/reference warnings.')
dest=ROOT.parents[0]/'pdf'; dest.mkdir(exist_ok=True)
shutil.copy2(M/'main.pdf',dest/'EAAI_Manuscrito_Sensoriamento_Virtual_2026-11-14.pdf')
print('Compiled review PDF with resolved citations and no overfull boxes.',flush=True)
