# Revisão do manuscrito EAAI — estado em 14 de novembro de 2026

O artigo agora reporta a análise dos nove cenários CFD cruzados: seis cenários de desenvolvimento e três reservados, avaliados uma única vez após o congelamento do protocolo. A análise exploratória de três casos documentada em 5 de novembro foi substituída como resultado principal; não misturar seus números com os resultados atuais.

## Alterações feitas

- Reescritos resumo, introdução, posicionamento, método, resultados, discussão e conclusão para a tarefa efetivamente avaliada: reconstrução contemporânea de temperatura, visibilidade e CO em seis locais virtuais omitidos.
- Documentado o desenho cruzado 3 x 3 de potência de fogo (5/10/20 MW) e velocidade de entrada (1/2/3 m/s), com seis casos para desenvolvimento e três reservados.
- Mantidos como comparadores o vizinho longitudinal mais próximo, a interpolação linear, Ridge e Random Forest, com divisão por cenário completo.
- Reportadas métricas brutas e projetadas para destacar a dependência dos resultados do Ridge em limites de saída.
- Atualizada a análise da regra local de severidade, inclusive desbalanceamento das faixas, subestimação e erros do índice gradual.
- Retiradas do texto as figuras de desempenho referentes somente à antiga avaliação de três casos; mantido o diagrama de posições.
- Compilado e inspecionado visualmente o PDF de dez páginas. Nenhum dado, limiar ou resultado foi inventado ou alterado nesta redação.

## Resultados principais atuais

No desenvolvimento de seis cenários, o Random Forest teve MAE menor que a interpolação linear em apenas 2/6 casos para cada grandeza. A média por cenário foi:

| Método | Temperatura (°C) | Visibilidade (m) | CO (ppm) |
|---|---:|---:|---:|
| Vizinho mais próximo | 9,86 | 2,97 | 3,21 |
| Interpolação linear | 9,85 | 3,89 | 3,67 |
| Ridge | 15,22 | 6,81 | 4,78 |
| Random Forest | 30,07 | 4,73 | 9,62 |

Nos três casos reservados, após a projeção compartilhada, a interpolação linear teve menor MAE médio de temperatura (5,49 °C), o Random Forest de visibilidade (0,369 m) e Ridge de CO (2,05 ppm). O MAE bruto de CO do Ridge foi 2,80 ppm e o de visibilidade, 3,03 m; os valores projetados caíram para 2,05 ppm e 1,96 m. Essa diferença impede interpretar a métrica pós-projeção isoladamente como qualidade aprendida pelo Ridge. Nenhum método liderou em todas as grandezas.

O Random Forest teve concordância com a regra local de 98,64% em P10V01 e 95,59% em P20V02, com subestimação de 0,83% e 2,80%. As referências Critical correspondem a 91,2% e 89,2% dos pares desses casos; P05V03 é inteiramente Low e sua concordância não testa discriminação. Esses números são comparações com uma regra de pesquisa, não taxas de falso alarme físico ou de risco humano.

## Limites e leitura editorial

Os nove casos usam a mesma geometria idealizada, malha, solver, fonte e configuração. Não há validação física, estudo de convergência de malha, nova geometria, modelo de resposta de sensor ou avaliação operacional. O filtro min--max é exploratório e não valida suporte multivariado nem segurança. Os limites locais de T, visibilidade e CO são escolhas metodológicas documentadas na dissertação final; a agregação pelo máximo é uma escolha explícita deste estudo, não uma regra de norma ou implementação recuperada.

O resultado sustenta uma comparação reprodutível e análise de falhas, não superioridade geral de ML nem novidade algorítmica demonstrada. A adequação à EAAI continua incerta e merece avaliação dos autores antes da submissão.

## Atualização documental — 14 de novembro de 2026

O coautor Prof. Saulo aprovou as modificações desta versão. O financiamento foi confirmado como: “This work was carried out with support from the National Council for Scientific and Technological Development (CNPq), Brazil, under Funding Code 131754/2025-4.” A declaração foi incorporada ao manuscrito.

## Pendências

Ainda não há depósito público persistente nem DOI para os dados e códigos revisados. A submissão permanece pendente do depósito e da atualização de sua citação no manuscrito. Nenhuma nova submissão foi realizada nesta etapa.

Para os arquivos detalhados de protocolo, auditoria e avaliação final, consultar `../eaai-development-six-scenario-2026-11-07/`. O registro `audit/final-holdout-record.json` deve ser preservado; não executar novamente o benchmark reservado.
