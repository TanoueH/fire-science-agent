# Revisão EAAI — estado em 14 de novembro de 2026

A versão atual de `manuscript/main.tex` incorpora a análise dos nove cenários CFD: seis casos de desenvolvimento com validação por cenário completo e três casos reservados avaliados uma vez conforme protocolo congelado. O PDF atualizado e a tabela de alteração estão na pasta `manuscript/` e `output/pdf/`.

## Arquivos atuais

- `manuscript/main.tex`, `references.bib`, `tables/` e `figures/`: fonte do artigo revisto.
- `manuscript/main.pdf`: PDF compilado desta versão.
- `manuscript/CHANGELOG_REVISAO_2026-11-07.md`: resumo das alterações científicas e editoriais.
- `../EAAI_Manuscrito_Revisado_9_Cenarios_2026-11-14.zip`: fonte LaTeX, PDF, bibliografia, figura, tabelas e pacote complementar.
- `../eaai-development-six-scenario-2026-11-07/`: protocolos, dados, auditorias e resultados completos das nove simulações.
- `../EAAI_Development_6_Scenarios_2026-11-07.zip`: arquivo portátil dos dados e da avaliação, sem alterações científicas nesta atualização.

## Reproduzir e preservar a avaliação final

A etapa de desenvolvimento pode ser reproduzida com os comandos indicados em `../eaai-development-six-scenario-2026-11-07/LEIA-ME.md`. A avaliação de P05V03, P10V01 e P20V02 já foi executada uma única vez. Não executar de novo `run_reserved_benchmark.py`: seu registro em `audit/final-holdout-record.json` existe para preservar essa condição.

Os scripts `run_reconstruction.py` e `verify_package.py` nesta pasta são do benchmark exploratório anterior de três cenários. Eles não reproduzem os resultados finais descritos no manuscrito atualizado. A tabela atual é referida no protocolo e relatório de seis cenários, não nesses scripts históricos.

## Estado científico e editorial

Os resultados não sustentam superioridade geral do aprendizado de máquina. A projeção dos valores de Ridge afeta materialmente algumas métricas; os valores brutos e projetados são ambos informados. A regra local de severidade é metodológica, não validada para segurança humana, alarmes ou operação. Não há validação física, de malha ou de outra geometria, e a novidade algorítmica para a EAAI não está estabelecida.

O coautor Prof. Saulo aprovou as modificações desta versão, e a declaração de apoio do CNPq foi confirmada e incorporada. Ainda não foi atribuído DOI público ao depósito revisado. A submissão permanece pendente do depósito público persistente dos dados/código e da atualização de sua citação. Não houve submissão nesta etapa.
