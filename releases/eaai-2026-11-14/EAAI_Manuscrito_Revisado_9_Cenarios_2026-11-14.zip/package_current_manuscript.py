"""Package the revised EAAI manuscript and its companion reproducibility archive."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent
OUT = ROOT.parent
ARCHIVE = OUT / "EAAI_Manuscrito_Revisado_9_Cenarios_2026-11-14.zip"
MANIFEST = ROOT / "MANIFEST_EAAI_2026-11-14.json"
COMPANION = OUT / "EAAI_Development_6_Scenarios_2026-11-07.zip"


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


paths = [
    ROOT / "ALTERACOES.md",
    ROOT / "LEIA-ME.md",
    ROOT / "STATUS.json",
    ROOT / "build_manuscript.py",
    ROOT / "package_current_manuscript.py",
    ROOT / "requirements-lock.txt",
    ROOT / "manuscript" / "main.tex",
    ROOT / "manuscript" / "main.pdf",
    ROOT / "manuscript" / "main.bbl",
    ROOT / "manuscript" / "references.bib",
    ROOT / "manuscript" / "CHANGELOG_REVISAO_2026-11-07.md",
    ROOT / "manuscript" / "tables" / "development-mae-rows.tex",
    ROOT / "manuscript" / "tables" / "mae-rows.tex",
    ROOT / "manuscript" / "tables" / "severity-rows.tex",
    ROOT / "manuscript" / "figures" / "site-layout.png",
    COMPANION,
]
missing = [str(path) for path in paths if not path.is_file()]
if missing:
    raise FileNotFoundError("Missing package files: " + ", ".join(missing))

entries = []
for path in paths:
    try:
        arcname = path.relative_to(ROOT).as_posix()
    except ValueError:
        arcname = "supplementary/" + path.name
    entries.append({"path": arcname, "bytes": path.stat().st_size, "sha256": sha256(path)})

manifest = {
    "package": ARCHIVE.name,
    "created": "2026-11-14",
    "purpose": "Revised author-review manuscript and reproducibility archive for the nine-scenario evaluation",
    "submission_ready": False,
    "files": entries,
}
MANIFEST.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
(ROOT / "MANIFEST.json").write_text(
    json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
)

with zipfile.ZipFile(ARCHIVE, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for path, entry in zip(paths, entries):
        archive.write(path, arcname=entry["path"])
    archive.write(MANIFEST, arcname=MANIFEST.name)

with zipfile.ZipFile(ARCHIVE) as archive:
    bad_member = archive.testzip()
    if bad_member:
        raise RuntimeError(f"ZIP CRC failure: {bad_member}")
    for entry in entries:
        if hashlib.sha256(archive.read(entry["path"])).hexdigest() != entry["sha256"]:
            raise RuntimeError(f"SHA-256 mismatch: {entry['path']}")

print(json.dumps({
    "archive": str(ARCHIVE),
    "bytes": ARCHIVE.stat().st_size,
    "members_verified": len(entries),
    "crc_check_passed": True,
    "archive_sha256": sha256(ARCHIVE),
    "manifest_sha256": sha256(MANIFEST),
}, indent=2))
